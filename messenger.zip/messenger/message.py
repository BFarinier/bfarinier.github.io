from __future__ import annotations

import struct

from datetime import datetime
from typing import AnyStr, Protocol
from enum import IntEnum

message = tuple[int, datetime, int, AnyStr]


# Python 3.10 and below
#
# from enum import Enum
#
# class Code(int, Enum):
#     CONNECT_REQUEST = 0
#     CONNECT_RESPONSE = 1
#     USERS_REQUEST = 2
#     USERS_RESPONSE = 3
#     MESSAGES_REQUEST = 4
#     MESSAGES_RESPONSE = 5
#     POST_REQUEST = 6
#     POST_RESPONSE = 7
#
#     @staticmethod
#     def decode(data: bytes) -> Code:
#         if len(data) > 0 and 0 <= data[0] <= 7:
#             return Code(data[0])
#         else:
#             raise ValueError(repr(data))


class Code(IntEnum):
    CONNECT_REQUEST = 0
    CONNECT_RESPONSE = 1
    USERS_REQUEST = 2
    USERS_RESPONSE = 3
    MESSAGES_REQUEST = 4
    MESSAGES_RESPONSE = 5
    POST_REQUEST = 6
    POST_RESPONSE = 7

    @staticmethod
    def decode(data: bytes) -> Code:
        if len(data) > 0 and 0 <= data[0] <= 7:
            return Code(data[0])
        else:
            raise ValueError(repr(data))


class Message(Protocol):

    code: Code
    userid: int

    @classmethod
    def decode(cls, data: bytes) -> Message:
        ...

    def encode(self) -> bytes:
        ...


# Example for ConnectResponse messages implemented with a class
class ConnectResponse(Message):

    code = Code.CONNECT_RESPONSE

    def __init__(self, userid: int) -> None:
        self.userid = userid

    @classmethod
    def decode(cls, data: bytes) -> ConnectResponse:
        # If the length of the data does not match the expected size, raise an exception.
        if len(data) != struct.calcsize('!BQ'):
            raise ValueError(repr(data))

        (c, uid) = struct.unpack('!BQ', data)

        # If the unpacked message code does not match the expected code, raise an exception.
        if c != cls.code:
            raise ValueError(repr(data))

        return ConnectResponse(uid)

    def encode(self) -> bytes:
        return struct.pack('!BQ', self.code, self.userid)


# Example for ConnectResponse messages implemented with two functions
def decode_connect_response(data: bytes) -> int:
    # If the length of the data does not match the expected size, raise an exception.
    if len(data) != struct.calcsize('!BQ'):
        raise ValueError(repr(data))

    (c, uid) = struct.unpack('!BQ', data)

    # If the unpacked message code does not match the expected code, raise an exception.
    if c != Code.CONNECT_RESPONSE:
        raise ValueError(repr(data))

    return uid


def encode_connect_response(userid: int) -> bytes:
    return struct.pack('!BQ', Code.CONNECT_RESPONSE, userid)
