%token <string> IDENT
%token <int> CONSTANT
%token TYPEVOID TYPEINT
%token ANDAND BARBAR EQEQ BANGEQ LE LT GE GT EQ PLUS MINUS STAR BANG
%token LPAREN RPAREN LBRACE RBRACE LBRACKET RBRACKET COMMA SEMICOLON
%token ASSERT IF ELSE WHILE RETURN
%token EOF

%start <Syntax.Func.t list> main
%{
  module Spa = struct end
  open Syntax
%}

%%

(******************************************************************************)

let call_expression ==
  | id = IDENT; ael = delimited(LPAREN,separated_list(COMMA,expression),RPAREN);
    { id, ael }

 
let primary_expression :=
  | tu = delimited(LPAREN,tuple,RPAREN); { tu }
  | located (
    | id = IDENT; { Expr.Var id }
    | ct = CONSTANT; { Expr.Cst ct }
    )

let postfix_expression :=
  | primary_expression
  | located (
    | (id, ael) = call_expression; { Expr.Call (id, ael) }
    )

let unary_expression :=
  | postfix_expression
  | located (
    | uo = unary_operator; ue = unary_expression;
      { Expr.Unop (uo, ue) }
    )

let unary_operator ==
  | MINUS; { Expr.Neg }

let multiplicative_expression :=
  | unary_expression
  | located(
    | me = multiplicative_expression; mo = multiplicative_operator; ue = unary_expression;
      { Expr.Bnop (mo, me, ue) }
    )

let multiplicative_operator ==
  | STAR;  { Expr.Mul }

let additive_expression :=
  | multiplicative_expression
  | located (
    | ae = additive_expression; ao = additive_operator; me = multiplicative_expression;
      { Expr.Bnop (ao, ae, me) }
    )

let additive_operator ==
  | PLUS;  { Expr.Add }
  | MINUS; { Expr.Sub }

let expression ==
  | additive_expression

let tuple :=
  | expression
  | located (
    | ex = expression; COMMA; le = separated_nonempty_list(COMMA,expression);
      { Expr.Tuple (ex :: le) }
    )

let primary_condition :=
  | cd = delimited(LPAREN,condition,RPAREN); { cd }

let relational_condition :=
  | located (
    | BANG; pc = primary_condition;
      { Cond.Not pc }
    | e1 = expression; ro = relational_operator; e2 = expression;
      { Cond.Atom (ro, e1, e2) }
    )

let relational_operator ==
  | EQEQ; { Cond.Eq }
  | BANGEQ; { Cond.Nq }
  | LE; { Cond.Le }
  | LT; { Cond.Lt }
  | GE; { Cond.Ge }
  | GT; { Cond.Gt }

let conjunctive_condition :=
  | relational_condition
  | located (
    | ce = conjunctive_condition; ANDAND; re = relational_condition;
      { Cond.And (ce, re) }
    )

let disjunctive_condition :=
  | conjunctive_condition
  | located (
    | de = disjunctive_condition; BARBAR; ce = conjunctive_condition;
      { Cond.Or (de, ce) }
    )

let condition :=
  | disjunctive_condition

(******************************************************************************)

let primary_location :=
  | id = IDENT; { Tree.Leaf id }
  | lo = delimited(LPAREN,location,RPAREN); { lo }

let location :=
  | ll = separated_nonempty_list(COMMA,primary_location);
    { match ll with [ lo ] -> lo | _ -> Tree.Node ll }

let type_specifier := 
  | TYPEINT; { Tree.Leaf () }
  | tl = delimited(LBRACKET,separated_list(COMMA,type_specifier),RBRACKET);
    { Tree.Node tl }

let statement :=
  | located (
    | ts = type_specifier; lo = location; SEMICOLON;
      { Stmt.Decl (ts, lo, None) }
    | ts = type_specifier; lo = location; EQ; tu = tuple; SEMICOLON;
      { Stmt.Decl (ts, lo, Some tu) }
    | lo = location; EQ; tu = tuple; SEMICOLON;
      { Stmt.Assign (lo, tu) }
    | (id, ael) = call_expression; SEMICOLON;
      { Stmt.Do (id, ael) }
    | ASSERT; pc = primary_condition; SEMICOLON;
      { Stmt.Assert pc}
    | RETURN; tu = tuple?; SEMICOLON;
      { Stmt.Return tu }
    | IF; pc = primary_condition; blt = block; ELSE; ble = block;
      { Stmt.If (pc, blt, ble) }
    | IF; pc = primary_condition; bl = block;
      { Stmt.If (pc, bl, []) }
    | WHILE; pc = primary_condition; bl = block;
      { Stmt.While (pc, bl) }
    )

let block :=
  | sl = delimited(LBRACE,list(statement),RBRACE); { sl }

let parameter :=
  | ts = type_specifier; id = IDENT; { ts, id }

let function_type :=
  | TYPEVOID; { None }
  | ts = type_specifier; { Some ts }

let function_definition :=
  | located (
    | ft = function_type;
      id = IDENT;
      pl = delimited(LPAREN,separated_list(COMMA,parameter),RPAREN);
      bl = block;
      { Func.
        { func_name = id;
          func_rettyp = ft;
          func_params = pl;
          func_body = bl;
        }
      }
    )

(******************************************************************************)

(* [located(x)] recognizes the same input fragment as [x] and wraps its
   semantic value of type ['a] as a value of type ['a located]. *)

let located(x) ==
  ~ = x; { { startpos = $startpos; endpos = $endpos; value = x } }
 
let main := dl = list(function_definition); EOF; { dl }
