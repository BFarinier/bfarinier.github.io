open Core
open Lang

module Make (D : Domains.Sigs.DOMAIN) = struct
  module Alarm = struct
    type t = AssertionFailure of Cond.t [@@deriving eq, ord]
  end

  include Alarm

  type alarm = Position.t * (Alarm.t * D.t)

  let pp fmt (alarm, state) =
    match alarm with
    | Alarm.AssertionFailure cond ->
        Format.fprintf fmt "AssertFailure %s with@ @[<hv>%a@]"
          (Format.asprintf "%a" Cond.pp cond)
          D.pp state


  let pp fmt (position, alarm_state) =
    Format.fprintf fmt "@[<2>%a, %a@]" Position.pp position pp alarm_state


  let assertion_failure pos expr state =
    (pos, (Alarm.AssertionFailure expr, state))


  module Map = Map.Make (Alarm)

  module Set = struct
    type t = D.t list Map.t Position.Map.t

    let empty = Position.Map.empty

    let is_empty t = Position.Map.is_empty t

    let add state list =
      let list = List.filter (fun t -> not (D.leq t state)) list in
      if List.for_all (fun t -> not (D.leq state t)) list then state :: list
      else list


    let add (alarm, state) alarms =
      Map.add alarm
        (add state
           (match Map.find_opt alarm alarms with
           | None -> []
           | Some list -> list))
        alarms


    let add (position, alarm_state) positions =
      Position.Map.add position
        (add alarm_state
           (match Position.Map.find_opt position positions with
           | None -> Map.empty
           | Some alarms -> alarms))
        positions


    let fold f (t : t) acc =
      Position.Map.fold
        (fun pos t acc ->
          Map.fold
            (fun alr t acc ->
              List.fold_left (fun acc stt -> f (pos, (alr, stt)) acc) acc t)
            t acc)
        t acc


    let iter f (t : t) =
      Position.Map.iter
        (fun pos t ->
          Map.iter (fun alr t -> List.iter (fun stt -> f (pos, (alr, stt))) t) t)
        t


    let iteri f t =
      let cnt = ref (-1) in
      iter
        (fun alarm ->
          incr cnt;
          f !cnt alarm)
        t


    let cardinal t = fold (fun _ i -> i + 1) t 0

    let elements t = fold List.cons t [] |> List.rev

    let pp fmt t =
      Format.pp_print_list
        ~pp_sep:(fun fmt () -> Format.fprintf fmt "@\n@\n")
        pp fmt (elements t)


    let merge s t =
      let mn, mx = if cardinal s > cardinal t then (t, s) else (s, t) in
      fold add mn mx
  end
end
