open Core
open Lang

module Inlined (Domain : Domains.Sigs.DOMAIN) = struct
  module Alarm = Alarm.Make (Domain)
  open Inlined

  (******************************************************************************)
  (**************************** BEGIN TODO **************************************)

  type state = Domain.t * Alarm.Set.t

  let rec fixpoint (f : state -> state) ((dom, alr) as stt : state) : state =
    not_yet_implemented ()


  let rec eval_stmt (stmt : Stmt.t) ((dom, alr) as stt : state) : state =
    match stmt.stmt_desc with
    | Stmt.Assert c ->
        let alr =
          let dom = not_yet_implemented () in
          (* Create an alarm for the domain dom and add it to the set of alarms alr. *)
          Alarm.Set.add (Alarm.assertion_failure stmt.stmt_pos c dom) alr
        in
        not_yet_implemented ()
    | Stmt.Assign (_, _) -> not_yet_implemented ()
    | Stmt.If (_, _, _) -> not_yet_implemented ()
    | Stmt.While (_, _) -> not_yet_implemented ()
    | Stmt.Print _ -> not_yet_implemented ()


  and eval_block (block : Stmt.block) (stt : state) : state =
    not_yet_implemented ()


  (**************************** END TODO ****************************************)
  (******************************************************************************)

  let eval program =
    (* Evaluate the program body with an initial state
       containing bindings for all program variables,
       and return the set of alarms. *)
    let dom =
      List.fold_left
        (fun d v -> Domain.extend v d)
        (Domain.init ()) program.vars
    in
    snd (eval_block program.body (dom, Alarm.Set.empty))
end
