open Core
open Lang

module Make (D : Domains.Sigs.DOMAIN) : sig
  type alarm

  val pp : Format.formatter -> alarm -> unit

  val assertion_failure : Position.t -> Cond.t -> D.t -> alarm

  module Set : sig
    type t

    val pp : Format.formatter -> t -> unit

    val empty : t

    val is_empty : t -> bool

    val add : alarm -> t -> t

    val cardinal : t -> int

    val elements : t -> alarm list

    val merge : t -> t -> t

    val fold : (alarm -> 'a -> 'a) -> t -> 'a -> 'a

    val iter : (alarm -> unit) -> t -> unit

    val iteri : (int -> alarm -> unit) -> t -> unit
  end
end
