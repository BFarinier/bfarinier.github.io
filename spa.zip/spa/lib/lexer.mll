{
  open Lexing
  open Parser

  exception Error of position * string
}

let white = [' ' '\t']+
let newline = '\r' | '\n' | "\r\n"
let id = ['a'-'z' 'A'-'Z' '_'] ['a'-'z' 'A'-'Z' '0'-'9' '_']*

let int = '-'? ['0'-'9']+

rule token = parse
| white   { token lexbuf }
| newline { new_line lexbuf; token lexbuf }
| eof     { EOF }

| "//" [^'\r' '\n']* { token lexbuf }

| int as i { CONSTANT (int_of_string i) }

| "void" | "VOID" { TYPEVOID }
| "int" | "INT" { TYPEINT }

| "assert" | "ASSERT" { ASSERT }
| "if" | "IF" { IF }
| "else" | "ELSE" { ELSE }
| "while" | "WHILE" { WHILE }
| "return" | "RETURN" { RETURN }

| "&&" { ANDAND }
| "||" { BARBAR }
| "==" { EQEQ }
| "!=" { BANGEQ }
| "<=" { LE }
| "<"  { LT }
| ">=" { GE }
| ">"  { GT }
| "="  { EQ }
| "+"  { PLUS }
| "-"  { MINUS }
| "*"  { STAR }
| "!"  { BANG }
| "("  { LPAREN }
| ")"  { RPAREN }
| "{"  { LBRACE }
| "}"  { RBRACE }
| "["  { LBRACKET }
| "]"  { RBRACKET }
| ","  { COMMA }
| ";"  { SEMICOLON }

| id as s { IDENT s }
| _ { let loc = Lexing.lexeme_start_p lexbuf in
      raise (Error (loc, "Unexpected character")) }
