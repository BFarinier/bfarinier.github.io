open Core
open Lang

type t = Bottom | Constant of Z.t | Top

let top = Top

let is_top t = t = Top

let bottom = Bottom

let is_bottom t = t = Bottom

let leq _ _ = not_yet_implemented ()

let join _ _ = not_yet_implemented ()

(* More on this later. *)
let widen s t = join s t

let meet _ _ = not_yet_implemented ()

let cst i = Constant i

let rand _ _ = not_yet_implemented ()

let unop (_ : Expr.unop) _ = not_yet_implemented ()

let bnop (_ : Expr.bnop) _ _ = not_yet_implemented ()

let comp (_ : Cond.comp) _ _ = not_yet_implemented ()

(*
let bwd_unop _ t ~result:_ = t

let bwd_bnop _ s t ~result:_ = (s, t)
*)

let pp fmt t =
  match t with
  | Top -> Format.pp_print_string fmt "⊤"
  | Bottom -> Format.pp_print_string fmt "⊥"
  | Constant i -> Format.fprintf fmt "{%a}" Z.pp_print i
