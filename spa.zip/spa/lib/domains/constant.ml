open Core
open Lang

type t = Bottom | Constant of Z.t | Top

let top = Top

let is_top t = t = Top

let bottom = Bottom

let is_bottom t = t = Bottom

let leq (_ : t) (_ : t) : bool = not_yet_implemented ()

let join (_ : t) (_ : t) : t = not_yet_implemented ()

(* More on this later. *)
let widen s t = join s t

let meet (_ : t) (_ : t) : t = not_yet_implemented ()

let cst i = Constant i

let rand (_ : Z.t) (_ : Z.t) : t = not_yet_implemented ()

let unop (_ : Expr.unop) (_ : t) : t = not_yet_implemented ()

let bnop (_ : Expr.bnop) (_ : t) (_ : t) : t = not_yet_implemented ()

let comp (_ : Cond.comp) (_ : t) (_ : t) : t * t = not_yet_implemented ()

(*
let bwd_unop (_ : Expr.unop) (t : t) ~result:_ : t = t

let bwd_bnop (_ : Expr.bnop) (s : t) (t : t) ~result:_ : t * t = (s, t)
*)

let pp fmt t =
  match t with
  | Top -> Format.pp_print_string fmt "⊤"
  | Bottom -> Format.pp_print_string fmt "⊥"
  | Constant i -> Format.fprintf fmt "{%a}" Z.pp_print i
