open Core
open Lang

module Simple = struct
  type t = Bot | Zero | NegZero | PosZero | Top [@@deriving eq, ord]

  let top = Top

  let is_top t = t = Top

  let bottom = Bot

  let is_bottom t = t = Bot

  let leq _ _ = not_yet_implemented ()

  let join _ _ = not_yet_implemented ()

  (* More on this later. *)
  let widen s t = join s t

  let meet _ _ = not_yet_implemented ()

  let cst i =
    if i < Z.zero then NegZero else if i > Z.zero then PosZero else Zero


  let rand _ _ = not_yet_implemented ()

  let bnop (_ : Expr.bnop) _ _ = not_yet_implemented ()

  let unop (_ : Expr.unop) _ = not_yet_implemented ()

  let comp (_ : Cond.comp) _ _ = not_yet_implemented ()

  (*
  let bwd_unop _ t ~result:_ = t

  let bwd_bnop _ s t ~result:_ = (s, t)
  *)

  let pp fmt t =
    match t with
    | Bot -> Format.pp_print_string fmt "⊥"
    | Zero -> Format.pp_print_string fmt "{0}"
    | NegZero -> Format.pp_print_string fmt "{≤0}"
    | PosZero -> Format.pp_print_string fmt "{≥0}"
    | Top -> Format.pp_print_string fmt "⊤"
end

module Extended = struct
  module Internal = struct
    type t = Neg | Zero | Pos [@@deriving eq, ord]

    let of_int _ = not_yet_implemented ()
  end

  module S = Set.Make (Internal)

  type t = S.t

  let leq _ _ = not_yet_implemented ()

  let top = S.of_list [ Neg; Zero; Pos ]

  let is_top t = leq top t

  let bottom = S.empty

  let is_bottom t = S.is_empty t

  let join _ _ = not_yet_implemented ()

  let widen _ _ = not_yet_implemented ()

  let meet _ _ = not_yet_implemented ()

  let cst i = S.singleton (Internal.of_int i)

  let rand _ _ = not_yet_implemented ()

  let bnop (_ : Expr.bnop) _ _ = not_yet_implemented ()

  let unop (_ : Expr.unop) _ = not_yet_implemented ()

  let comp (_ : Cond.comp) _ _ = not_yet_implemented ()

  (*
  let bwd_unop _ t ~result:_ = t

  let bwd_bnop _ s t ~result:_ = (s, t)
  *)

  let pp fmt t =
    match (S.mem Neg t, S.mem Zero t, S.mem Pos t) with
    | false, false, false -> Format.pp_print_string fmt "⊥"
    | false, false, true -> Format.pp_print_string fmt "{>0}"
    | false, true, false -> Format.pp_print_string fmt "{=0}"
    | false, true, true -> Format.pp_print_string fmt "{≥0}"
    | true, false, false -> Format.pp_print_string fmt "{<0}"
    | true, false, true -> Format.pp_print_string fmt "{≠0}"
    | true, true, false -> Format.pp_print_string fmt "{≤0}"
    | true, true, true -> Format.pp_print_string fmt "⊤"
end
