module Make (_ : Sigs.VALUE) : Sigs.DOMAIN
