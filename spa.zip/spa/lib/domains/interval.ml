open Core
open Lang

type bound = NegInf | Constant of Z.t | PosInf

let _zero = Constant Z.zero

let _one = Constant Z.one

let _compare (a : bound) (b : bound) =
  match (a, b) with
  | NegInf, NegInf -> 0
  | NegInf, _ -> -1
  | _, NegInf -> 1
  | PosInf, PosInf -> 0
  | PosInf, _ -> 1
  | _, PosInf -> -1
  | Constant i, Constant j -> compare i j


type t = Interval of bound * bound | Bottom

let top = Interval (NegInf, PosInf)

let is_top t = t = top

let bottom = Bottom

let is_bottom t = t = Bottom

let leq (_ : t) (_ : t) : bool = not_yet_implemented ()

let join (_ : t) (_ : t) : t = not_yet_implemented ()

(* More on this later. *)
let widen (_ : t) (_ : t) : t = not_yet_implemented ()

let meet (_ : t) (_ : t) : t = not_yet_implemented ()

let cst (_ : Z.t) : t = not_yet_implemented ()

let rand (_ : Z.t) (_ : Z.t) : t = not_yet_implemented ()

let unop (_ : Expr.unop) (_ : t) : t = not_yet_implemented ()

let bnop (_ : Expr.bnop) (_ : t) (_ : t) : t = not_yet_implemented ()

let comp (_ : Cond.comp) (_ : t) (_ : t) : t * t = not_yet_implemented ()

(*
let bwd_unop (_ : Expr.unop) (t : t) ~result:_ : t = t

let bwd_bnop (_ : Expr.bnop) (s : t) (t : t) ~result:_ : t * t = (s, t)
*)

let pp_bound fmt (b : bound) =
  match b with
  | NegInf -> Format.pp_print_string fmt "-∞"
  | Constant i -> Z.pp_print fmt i
  | PosInf -> Format.pp_print_string fmt "+∞"


let pp fmt (t : t) =
  match t with
  | Interval (NegInf, PosInf) -> Format.pp_print_string fmt "⊤"
  | Interval (lo, hi) -> Format.fprintf fmt "[%a, %a]" pp_bound lo pp_bound hi
  | Bottom -> Format.pp_print_string fmt "⊥"
