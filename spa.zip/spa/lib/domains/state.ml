open Core
open Lang

module Make (V : Sigs.VALUE) = struct
  type t = Bottom | State of V.t Var.Map.t

  let init () = State Var.Map.empty

  let bottom () = Bottom

  let is_bottom t = t = Bottom

  let leq _ _ = not_yet_implemented ()

  let join _ _ = not_yet_implemented ()

  (* More on this later. *)
  let widen _ _ = not_yet_implemented ()

  let meet _ _ = not_yet_implemented ()

  let extend v t =
    match t with
    | Bottom -> Bottom
    | State d -> State (Var.Map.add v V.top d)


  let forget v t =
    match t with
    | Bottom -> Bottom
    | State d -> State (Var.Map.remove v d)


  let assign _ _ _ = not_yet_implemented ()

  let filter _ _ = not_yet_implemented ()

  let pp_print_comma fmt () = Format.fprintf fmt ",@ "

  let pp_bindings fmt (v, i) =
    Format.fprintf fmt "@[%a ∈ %a@]" Var.pp_qualified v V.pp i


  let pp fmt t =
    match t with
    | Bottom -> Format.pp_print_string fmt "⊥"
    | State d ->
        Format.fprintf fmt "@[<2>{ %a }@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma pp_bindings)
          (Var.Map.bindings d)
end
