open Core
open Lang

module Make (V : Sigs.VALUE) = struct
  type t = Bottom | State of V.t Var.Map.t

  let init () = State Var.Map.empty

  let bottom () = Bottom

  let is_bottom t = t = Bottom

  let leq (_ : t) (_ : t) : bool = not_yet_implemented ()

  let join (_ : t) (_ : t) : t = not_yet_implemented ()

  (* More on this later. *)
  let widen (_ : t) (_ : t) : t = not_yet_implemented ()

  let meet (_ : t) (_ : t) : t = not_yet_implemented ()

  let extend v t =
    match t with
    | Bottom -> Bottom
    | State d -> State (Var.Map.add v V.top d)


  let forget v t =
    match t with
    | Bottom -> Bottom
    | State d -> State (Var.Map.remove v d)


  let assign (_ : Var.t) (_ : Expr.t) (_ : t) : t = not_yet_implemented ()

  let filter (_ : Cond.t) (_ : t) : t = not_yet_implemented ()

  let pp_print_comma fmt () = Format.fprintf fmt ",@ "

  let pp_binding fmt (v, i) =
    Format.fprintf fmt "@[%a ∈ %a@]" Var.pp_qualified v V.pp i


  let pp fmt t =
    match t with
    | Bottom -> Format.pp_print_string fmt "⊥"
    | State d -> Var.Map.pp pp_binding fmt d
end
