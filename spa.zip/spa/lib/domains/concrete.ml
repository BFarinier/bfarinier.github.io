open Core
open Lang

(******************************************************************************)
(*                                                                            *)
(* Program states and the concrete domain                                     *)
(*                                                                            *)
(* A program state is a mapping σ : 𝕍 → ℤ.                                    *)
(* Here, states are represented by finite maps type state = Z.t Var.Map.t;    *)
(* variables not present in the map are assumed to be absent only for         *)
(* implementation convenience. The project ensure all reads are defined.      *)
(*                                                                            *)
(* The concrete domain is the powerset of states:                             *)
(*         C = ℘ (𝕊)   where 𝕊 = 𝕍 → ℤ.                                       *)
(* In this file, type t = State.t is a finite set of states (a representation *)
(* of an element of ℘ (𝕊)).                                                   *)
(*                                                                            *)
(******************************************************************************)

type state = Z.t Var.Map.t

module State = Set.Make (struct
  type t = Z.t Var.Map.t

  let compare s t = Var.Map.compare Z.compare s t
end)

module Value = Set.Make (Z)

type t = State.t

(* The initial concrete element { ∅ } *)
let init () = State.singleton Var.Map.empty

(* ⊥ in the powerset domain, i.e. the empty set of states ∅. *)
let bottom () = State.empty

(* Tests whether an element is ⊥. *)
let is_bottom t = State.is_empty t

(* Partial order of the powerset domain: leq(X, Y) = X ⊆ Y *)
let leq s t = State.subset s t

(* Least upper bound in the powerset domain: join(X, Y) = X ∪ Y. *)
let join s t = State.union s t

(* Greatest lower bound in the powerset domain: meet(X, Y) = X ∩ Y. *)
let meet s t = State.inter s t

(* More on this later. *)
let widen s t = State.union s t

let extend _ t = t

let forget v t = State.map (fun map -> Var.Map.remove v map) t

let pp_print_semicolon fmt () = Format.fprintf fmt ";@\n"

let pp_bindings fmt (v, i) =
  Format.fprintf fmt "@[%a = %a@]" Var.pp_qualified v Z.pp_print i


let pp_map fmt map =
  Format.fprintf fmt "@[<2>{ %s }@]"
    (String.concat ", "
       (List.map (Format.asprintf "%a" pp_bindings) (Var.Map.bindings map)))


let pp fmt stt =
  Format.fprintf fmt "@[<2>[ %a ]@]"
    (Format.pp_print_list ~pp_sep:pp_print_semicolon pp_map)
    (State.to_list stt)


(******************************************************************************)

(* Collecting semantics of expressions: ⟦e⟧(σ) ⊆ ℤ. *)
let rec eval_expr (expr : Expr.t) (stt : state) : Value.t =
  match expr with
  (* ⟦Cst i⟧(σ) = { i }. *)
  | Expr.Cst i -> Value.singleton (Z.of_int i)
  (* ⟦Var v⟧(σ) = { σ(v) }. *)
  | Expr.Var v -> Value.singleton (Var.Map.find v stt)
  (* ⟦Unop(u,e)⟧(σ) = { u(x) | x ∈ ⟦e⟧(σ) }. *)
  | Expr.Unop (u, e) ->
      (* Compute ⟦e⟧(σ) recursively. *)
      let e = eval_expr e stt in
      (* Value.map f S = { f(x) | x ∈ S }. *)
      Value.map
        (match u with
        | Expr.Neg -> Z.neg)
        e
  (* ⟦Bnop(b,e1,e2)⟧(σ) = { b(x,y) | x ∈ ⟦e1⟧(σ) ∧ y ∈ ⟦e2⟧(σ) }. *)
  | Expr.Bnop (b, e1, e2) ->
      (* Compute ⟦e1⟧(σ) and ⟦e2⟧(σ) recursively. *)
      let e1 = eval_expr e1 stt in
      let e2 = eval_expr e2 stt in
      (* Value.map2 f S1 S2 = { f(x,y) | x ∈ S1 ∧ y ∈ S2 }. *)
      Value.map2
        (match b with
        | Expr.Add -> Z.add
        | Expr.Sub -> Z.sub
        | Expr.Mul -> Z.mul)
        e1 e2
  (* ⟦Rand(lo,hi)⟧(σ) = { z ∈ ℤ | lo ≤ z ≤ hi }. *)
  | Expr.Rand (lo, hi) ->
      Value.of_list (List.init (hi - lo + 1) (fun i -> Z.of_int (lo + i)))


(* Collecting semantics of conditions: ⟦c⟧(Σ) = { σ ∈ Σ | c may hold in σ }. *)
let rec eval_cond (cond : Cond.t) (state : State.t) : State.t =
  match cond with
  (* ⟦Atom(c,e1,e2)⟧(Σ) = { σ ∈ Σ | ∃x ∈ ⟦e1⟧(σ), ∃y ∈ ⟦e2⟧(σ), c(x,y) }. *)
  | Cond.Atom (c, e1, e2) ->
      (* State.filter p Σ = { σ ∈ Σ | p(σ) }. *)
      State.filter
        (fun stt ->
          (* Compute ⟦e1⟧(σ) and ⟦e2⟧(σ) recursively. *)
          let e1 = eval_expr e1 stt in
          let e2 = eval_expr e2 stt in
          (* Value.exists2 R S1 S2 = ∃x ∈ S1, ∃y ∈ S2, R x y. *)
          Value.exists2
            (match c with
            | Cond.Eq -> ( = )
            | Cond.Nq -> ( <> )
            | Cond.Le -> ( <= )
            | Cond.Lt -> ( < )
            | Cond.Ge -> ( >= )
            | Cond.Gt -> ( > ))
            e1 e2)
        state
  (* ⟦And(c1,c2)⟧(Σ) = ⟦c1⟧(Σ) ∩ ⟦c2⟧(Σ). *)
  | Cond.And (c1, c2) -> State.inter (eval_cond c1 state) (eval_cond c2 state)
  (* ⟦Or(c1,c2)⟧(X) = ⟦c1⟧(Σ) ∪ ⟦c2⟧(Σ). *)
  | Cond.Or (c1, c2) -> State.union (eval_cond c1 state) (eval_cond c2 state)


(* Filter states by a condition: filter c Σ = ⟦c⟧(Σ). *)
let filter (cond : Cond.t) (state : State.t) : State.t = eval_cond cond state

(* Collecting semantics of assignment: assign v e Σ = { σ[v↦i] | σ ∈ Σ ∧ i ∈ ⟦e⟧(σ) }. *)
let assign (var : Var.t) (expr : Expr.t) (state : State.t) : State.t =
  (* State.fold f Σ acc iterates over all σ ∈ Σ and returns f(σₙ, ... f(σ₂, f(σ₁, acc)) ...). *)
  State.fold
    (fun stt acc ->
      (* Value.fold g I acc iterates over all i ∈ I and returns g(iₘ, ... g(i₂, g(i₁, acc)) ...). *)
      Value.fold
        (fun i acc ->
          (* Add the updated state σ[var↦i] to the accumulator. *)
          State.add (Var.Map.add var i stt) acc)
          (* Compute the set ⟦expr⟧(σ) for the current state σ. *)
        (eval_expr expr stt) acc)
    (* Accumulator starts at ∅, so the result is exactly { σ[var↦i] | σ ∈ Σ ∧ i ∈ ⟦expr⟧(σ) }. *)
    state State.empty
