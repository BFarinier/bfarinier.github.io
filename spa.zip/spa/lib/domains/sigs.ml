open Core
open Lang

module type VALUE = sig
  type t

  val top : t

  val bottom : t

  val is_top : t -> bool

  val is_bottom : t -> bool

  val leq : t -> t -> bool

  val join : t -> t -> t

  val widen : t -> t -> t

  val meet : t -> t -> t

  val cst : Z.t -> t

  val rand : Z.t -> Z.t -> t

  val unop : Expr.unop -> t -> t

  val bnop : Expr.bnop -> t -> t -> t

  val comp : Cond.comp -> t -> t -> t * t

  val pp : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

  (*
  val bwd_unop : Expr.unop -> t -> result:t -> t

  val bwd_bnop : Expr.bnop -> t -> t -> result:t -> t * t
  *)
end

module type DOMAIN = sig
  type t

  val init : unit -> t

  val bottom : unit -> t

  val is_bottom : t -> bool

  val leq : t -> t -> bool

  val join : t -> t -> t

  val meet : t -> t -> t

  val widen : t -> t -> t

  val extend : Var.t -> t -> t

  val forget : Var.t -> t -> t

  val assign : Var.t -> Expr.t -> t -> t

  val filter : Cond.t -> t -> t

  val pp : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]
end
