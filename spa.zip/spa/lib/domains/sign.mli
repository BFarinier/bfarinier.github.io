module Simple : Sigs.VALUE

module Extended : Sigs.VALUE
