module type BOOL = sig
  val get : unit -> bool
end

module Debug : BOOL

module Verbose : BOOL
