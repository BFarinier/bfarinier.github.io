include module type of Stdlib.Map

module type S = sig
  include Stdlib.Map.S

  val map2 : ('a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t

  val mapi2 : (key -> 'a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t

  val exists2 : (key -> 'a -> 'b -> bool) -> 'a t -> 'b t -> bool

  val for_all2 : (key -> 'a -> 'b -> bool) -> 'a t -> 'b t -> bool

  val pp :
    (Format.formatter -> key * 'a -> unit) -> Format.formatter -> 'a t -> unit
end

module Make (Ord : OrderedType) : S with type key = Ord.t
