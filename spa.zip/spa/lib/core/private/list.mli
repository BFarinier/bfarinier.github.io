include module type of Stdlib.List

val fold_left_map_filter :
  ('a -> 'b -> 'a * 'c option) -> 'a -> 'b t -> 'a * 'c t

val fold_left_map_concat : ('a -> 'b -> 'a * 'c t) -> 'a -> 'b t -> 'a * 'c t
