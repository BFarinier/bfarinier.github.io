include module type of Stdlib.Set

module type S = sig
  include Stdlib.Set.S

  val bind : (elt -> t) -> t -> t

  val bind2 : (elt -> elt -> t) -> t -> t -> t

  val map2 : (elt -> elt -> elt) -> t -> t -> t

  val filter2 : (elt -> elt -> bool) -> t -> t -> t * t

  val exists2 : (elt -> elt -> bool) -> t -> t -> bool

  val for_all2 : (elt -> elt -> bool) -> t -> t -> bool
end

module Make (Ord : OrderedType) : S with type elt = Ord.t
