include module type of Stdlib.Int

val hash : int -> int

module Map : sig
  include Stdlib.Map.S with type key = int

  val hash : ('a -> int) -> 'a t -> int
end

module Set : sig
  include Stdlib.Set.S with type elt = int

  val hash : t -> int
end

module Hashtbl : Stdlib.Hashtbl.S with type key = int
