include module type of Stdlib.String

module Map : sig
  include Stdlib.Map.S with type key = string

  val hash : ('a -> int) -> 'a t -> int
end

module Set : sig
  include Stdlib.Set.S with type elt = string

  val hash : t -> int
end

module Hashtbl : Stdlib.Hashtbl.S with type key = string
