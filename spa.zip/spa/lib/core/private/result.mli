include module type of Stdlib.Result

type 'a t = ('a, string) Stdlib.Result.t

val ok : 'a -> 'a t

val error : string -> 'a t

val error_exn : exn -> 'a t

val error_format : ('a, Format.formatter, unit, 'b t) format4 -> 'a

val error_printf : ('a, unit, string, 'b t) format4 -> 'a

module List : sig
  val map : ('a -> 'b t) -> 'a list -> 'b list t

  val fold_left : ('a -> 'b -> 'a t) -> 'a -> 'b list -> 'a t

  val fold_left2 : ('a -> 'b -> 'c -> 'a t) -> 'a -> 'b list -> 'c list -> 'a t

  val fold_left_map :
    ('acc -> 'a -> ('acc * 'b) t) -> 'acc -> 'a list -> ('acc * 'b list) t

  val map_collect : ('a -> 'b t) -> 'a list -> 'b list t

  val fold_left_collect : ('a -> 'b -> 'a t) -> 'a -> 'b list -> 'a t
end

module Monad : sig
  val ( >>| ) : 'a t -> ('a -> 'b) -> 'b t

  val ( >>= ) : 'a t -> ('a -> 'b t) -> 'b t

  val ( let+ ) : 'a t -> ('a -> 'b) -> 'b t

  val ( let* ) : 'a t -> ('a -> 'b t) -> 'b t

  val ok : 'a -> 'a t

  val error : string -> 'a t

  val error_exn : exn -> 'a t

  val error_format : ('a, Format.formatter, unit, 'b t) format4 -> 'a

  val error_printf : ('a, unit, string, 'b t) format4 -> 'a
end
