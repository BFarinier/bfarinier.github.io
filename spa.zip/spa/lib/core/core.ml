include Stdlib
include Private
module Z = Zarith

module type DATATYPE = sig
  type t

  val compare : t -> t -> int

  val equal : t -> t -> bool

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit
end

type 'a result = 'a Result.t

let not_yet_implemented () = failwith "Not yet implemented."
