module type BOOL = sig
  val get : unit -> bool
end

module MakeBool (P : sig
  val value : string
end) =
struct
  let value = try bool_of_string (Sys.getenv P.value) with _ -> false

  let get () = value
end

module Debug = MakeBool (struct
  let value = "DEBUG"
end)

module Verbose = MakeBool (struct
  let value = "VERBOSE"
end)
