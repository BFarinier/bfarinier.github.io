open Core
open Result.Monad

let error_pos pos fmt =
  Format.kasprintf
    (fun str -> error_format "%a: %s." Position.pp_with_offset pos str)
    fmt


let type_error pos pp_a a pp_b b pp_c c =
  error_pos pos "%a has type %a but was expected of type %a" pp_a a pp_b b pp_c
    c


let invalid_number pos ident =
  error_pos pos "invalid number of arguments for function %s" ident


let unknown pos kind name = error_pos pos "unknown %s %s" kind name

let unknown_function pos name = unknown pos "function" name

let unknown_variable pos name = unknown pos "variable" name

(******************************************************************************)

module V = struct
  include Var

  let pp fmt t = debug fmt t
end

module Type = struct
  module Internal = struct
    type t = unit Syntax.Tree.t [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt (t : t) =
    match t with
    | Syntax.Tree.Leaf _ -> Format.pp_print_string fmt "int"
    | Syntax.Tree.Node l -> Pp.pp_tuple_brack pp fmt l


  let pp_opt fmt opt =
    match opt with
    | None -> Format.pp_print_string fmt "void"
    | Some t -> pp fmt t


  let int = Syntax.Tree.Leaf ()

  let tuple l = Syntax.Tree.Node l

  let is_int t = equal t int
end

module T = Type.Internal

module Loc = struct
  module Internal = struct
    type t = (V.t * T.t) Syntax.Tree.t
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt (t : t) =
    match t with
    | Syntax.Tree.Leaf (v, _) -> Format.pp_print_string fmt (Var.name v)
    | Syntax.Tree.Node l -> Pp.pp_tuple_paren pp fmt l


  let var v t = Syntax.Tree.Leaf (v, t)

  let tuple l = Syntax.Tree.Node l

  let wildcard = Var.named "_"
end

module L = Loc.Internal

module Expr = struct
  module Internal = struct
    type unop = Syntax.Expr.unop = Neg
    [@@deriving eq, ord, show { with_path = false }]

    type bnop = Syntax.Expr.bnop = Add | Sub | Mul
    [@@deriving eq, ord, show { with_path = false }]

    type t =
      | Cst of int
      | Var of V.t
      | Unop of unop * t
      | Bnop of bnop * t * t
      | Rand of int * int
      | Call of string * t list
      | Tuple of t list
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let string_of_unop = Expr.string_of_unop

  let string_of_bnop = Expr.string_of_bnop

  let rec pp fmt (t : t) =
    match t with
    | Cst i -> Format.pp_print_int fmt i
    | Var v -> Var.pp fmt v
    | Unop (u, ex) -> Pp.pp_unop pp_paren fmt (string_of_unop u) ex
    | Bnop (b, ex1, ex2) -> Pp.pp_bnop pp_paren fmt (string_of_bnop b) ex1 ex2
    | Rand (lo, hi) -> Pp.pp_rand fmt lo hi
    | Call (s, exs) -> Pp.pp_call pp fmt s exs
    | Tuple l -> Pp.pp_tuple_paren pp fmt l


  and pp_paren fmt (t : t) =
    match t with
    | Cst i when i < 0 -> Pp.pp_paren pp fmt t
    | Cst _ | Var _ | Rand _ | Call _ | Tuple _ -> pp fmt t
    | Unop _ | Bnop _ -> Pp.pp_paren pp fmt t


  let cst i = Cst i

  let var v = Var v

  let unop u t = Unop (u, t)

  let bnop b t1 t2 = Bnop (b, t1, t2)

  let rand lo hi = Rand (lo, hi)

  let call s l = Call (s, l)

  let tuple l = Tuple l
end

module E = Expr.Internal
module Cond = Cond.Make (Expr)

module C = struct
  include Cond

  let pp fmt t = debug fmt t
end

module Stmt = struct
  module Internal = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of L.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
      | Do of string * E.t list
      | Return of E.t option
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  type builtin = BuiltInRand | BuiltInPrint

  let string_of_builtin (b : builtin) =
    match b with
    | BuiltInRand -> "rand"
    | BuiltInPrint -> "print"


  let builtin_of_string s =
    match s with
    | "rand" -> Some BuiltInRand
    | "print" -> Some BuiltInPrint
    | _ -> None


  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Pp.pp_assert Cond.pp fmt cd
    | Assign (lo, ex) -> Pp.pp_assign Loc.pp Expr.pp fmt lo ex
    | If (cd, bl, []) -> Pp.pp_if_then Cond.pp pp_block fmt cd bl
    | If (cd, bl1, bl2) -> Pp.pp_if_then_else Cond.pp pp_block fmt cd bl1 bl2
    | While (cd, bl) -> Pp.pp_while Cond.pp pp_block fmt cd bl
    | Print ex -> Pp.pp_print Expr.pp fmt ex
    | Do (s, exs) -> Pp.pp_do Expr.pp fmt s exs
    | Return None -> Pp.pp_return_none fmt ()
    | Return (Some ex) -> Pp.pp_return_some Expr.pp fmt ex


  and pp_block fmt lst = Pp.pp_block pp fmt lst

  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

module S = Stmt.Internal

module Func = struct
  module Internal = struct
    type t = {
      func_pos : Position.t; [@opaque]
      func_name : string;
      func_rettyp : T.t option;
      func_params : (V.t * T.t) list;
      func_locals : (V.t * T.t) list;
      func_body : S.block;
    }
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let pp_typed_var fmt (v, ty) = Format.fprintf fmt "%a %a" Type.pp ty Var.pp v

  let pp fmt { func_name; func_rettyp; func_params; func_locals; func_body; _ }
      =
    Pp.pp_func Type.pp_opt pp_typed_var Stmt.pp_block fmt func_name func_rettyp
      func_params func_locals func_body
end

module Env = struct
  type t = (string * Func.t) list

  let make list = List.map (fun func -> (func.Func.func_name, func)) list

  let find string t = List.assoc string t

  let functions t = List.map snd t
end

type program = { environment : Env.t; entrypoint : string }

let pp fmt { environment; _ } =
  Pp.pp_env Func.pp fmt (Env.functions environment)


(******************************************************************************)

let find_signature sigs pos string =
  match String.Map.find_opt string sigs with
  | Some (rettyp, l) -> ok (Either.Left string, rettyp, l)
  | None -> (
      match Stmt.builtin_of_string string with
      | Some (BuiltInRand as bi) ->
          ok (Either.Right bi, Some Type.int, [ Type.int; Type.int ])
      | Some (BuiltInPrint as bi) -> ok (Either.Right bi, None, [ Type.int ])
      | None -> unknown_function pos string)


let ensure_int pos exp ty =
  if Type.is_int ty then ok ()
  else type_error pos Expr.pp exp Type.pp ty Type.pp Type.int


let rec typed_expr sigs ctx ({ value; startpos; _ } : Syntax.Expr.t) =
  match value with
  | Syntax.Expr.Cst int -> ok (Expr.cst int, Type.int)
  | Syntax.Expr.Var string -> (
      match String.Map.find_opt string ctx with
      | Some (v, ty) -> ok (Expr.var v, ty)
      | None -> unknown_variable startpos string)
  | Syntax.Expr.Unop (u, exp) ->
      let* exp, typ = typed_expr sigs ctx exp in
      let* () = ensure_int startpos exp typ in
      ok (Expr.unop u exp, typ)
  | Syntax.Expr.Bnop (b, exp1, exp2) ->
      let* exp1, typ1 = typed_expr sigs ctx exp1 in
      let* exp2, typ2 = typed_expr sigs ctx exp2 in
      let* () = ensure_int startpos exp1 typ1 in
      let* () = ensure_int startpos exp2 typ2 in
      ok (Expr.bnop b exp1 exp2, typ1)
  | Syntax.Expr.Call (string, exps) -> (
      let* either = typed_call sigs ctx startpos string exps in
      match either with
      | Either.Right _ -> error_pos startpos "%s has type void" string
      | Either.Left (exp, rettyp) -> ok (exp, rettyp))
  | Syntax.Expr.Tuple exps ->
      let* exps, typs = typed_exprs sigs ctx exps in
      ok (Expr.tuple exps, Type.tuple typs)


and typed_exprs sigs ctx exps =
  let+ list = Result.List.map (typed_expr sigs ctx) exps in
  List.split list


and typed_call sigs ctx pos string exps =
  let* ident, rettyp, arity = find_signature sigs pos string in
  let* exps, typs = typed_exprs sigs ctx exps in
  if List.compare_lengths typs arity <> 0 then invalid_number pos string
  else if not (List.equal Type.equal typs arity) then
    error_pos pos "invalid argument types for function %s" string
  else
    match ident with
    | Either.Left string -> (
        match rettyp with
        | None -> ok (Either.Right (Stmt.Do (string, exps)))
        | Some rettyp -> ok (Either.Left (Expr.call string exps, rettyp)))
    | Either.Right bi -> (
        match (bi, exps) with
        | Stmt.BuiltInRand, [ lo; hi ] -> (
            match (lo, hi) with
            | Cst lo, Cst hi when lo <= hi ->
                ok (Either.Left (Expr.Rand (lo, hi), Type.int))
            | _ -> error_pos pos "invalid bounds for function rand")
        | Stmt.BuiltInPrint, [ exp ] -> ok (Either.Right (Stmt.Print exp))
        | _ -> invalid_number pos (Stmt.string_of_builtin bi))


let rec has_call (exp : Expr.t) =
  match exp with
  | Expr.Call _ -> true
  | Expr.Unop (_, exp) -> has_call exp
  | Expr.Bnop (_, exp1, exp2) -> has_call exp1 || has_call exp2
  | Expr.Tuple exps -> List.exists has_call exps
  | Expr.Cst _ | Expr.Var _ | Expr.Rand _ -> false


let rec typed_cond sigs ctx ({ value; startpos; _ } : Syntax.Cond.t) =
  match value with
  | Syntax.Cond.Atom (a, exp1, exp2) ->
      let* exp1, typ1 = typed_expr sigs ctx exp1 in
      let* exp2, typ2 = typed_expr sigs ctx exp2 in
      let* () = ensure_int startpos exp1 typ1 in
      let* () = ensure_int startpos exp2 typ2 in
      (* Flattened hoists calls before their statement, which would break the
         short-circuit evaluation of && and ||. *)
      if has_call exp1 || has_call exp2 then
        error_pos startpos "function call in condition"
      else ok (Cond.atom a exp1 exp2)
  | Syntax.Cond.Not cnd ->
      let* cnd = typed_cond sigs ctx cnd in
      ok (Cond.not cnd)
  | Syntax.Cond.And (cnd1, cnd2) ->
      let* cnd1 = typed_cond sigs ctx cnd1 in
      let* cnd2 = typed_cond sigs ctx cnd2 in
      ok (Cond.conj cnd1 cnd2)
  | Syntax.Cond.Or (cnd1, cnd2) ->
      let* cnd1 = typed_cond sigs ctx cnd1 in
      let* cnd2 = typed_cond sigs ctx cnd2 in
      ok (Cond.disj cnd1 cnd2)


let rec pp_syntax_loc fmt (t : Syntax.Stmt.loc) =
  match t with
  | Syntax.Tree.Leaf v -> Format.pp_print_string fmt v
  | Syntax.Tree.Node l -> Pp.pp_tuple_paren pp_syntax_loc fmt l


let rec typed_loc pos ctx (loc : Syntax.Stmt.loc) (typ : Type.t) =
  match (loc, typ) with
  | Syntax.Tree.Leaf "_", _ -> ok (Loc.var Loc.wildcard typ, typ)
  | Syntax.Tree.Leaf string, _ -> (
      match String.Map.find_opt string ctx with
      | None -> unknown_variable pos string
      | Some (v, ty) -> ok (Loc.var v ty, ty))
  | Syntax.Tree.Node l, Syntax.Tree.Node t when List.compare_lengths l t = 0 ->
      let* l =
        Result.List.map_collect
          (fun (loc, typ) -> typed_loc pos ctx loc typ)
          (List.combine l t)
      in
      let ll, lt = List.split l in
      ok (Loc.tuple ll, Type.tuple lt)
  | Syntax.Tree.Node _, _ ->
      error_pos pos "cannot unify %a with type %a" pp_syntax_loc loc Type.pp typ


(* Tuple assignments become sequential assignments in Flattened: a variable
   must not be read after being assigned. Calls are hoisted before the
   assignment, so their arguments are not reads. *)
let rec reads var (exp : Expr.t) =
  match exp with
  | Expr.Var v -> Var.equal var v
  | Expr.Unop (_, exp) -> reads var exp
  | Expr.Bnop (_, exp1, exp2) -> reads var exp1 || reads var exp2
  | Expr.Tuple exps -> List.exists (reads var) exps
  | Expr.Cst _ | Expr.Rand _ | Expr.Call _ -> false


let rec groups (loc : Loc.t) (exp : Expr.t) =
  match (loc, exp) with
  | Syntax.Tree.Node locs, Expr.Tuple exps ->
      List.concat (List.map2 groups locs exps)
  | _ -> [ (List.map fst (Syntax.Tree.flatten loc), exp) ]


let rec conflict list =
  match list with
  | [] -> false
  | (vars, _) :: list ->
      List.exists
        (fun (_, exp) -> List.exists (fun var -> reads var exp) vars)
        list
      || conflict list


(* The parser reads locations as expressions (see primary_location); a
   one-element tuple is a parenthesized location. *)
let rec syntax_loc ({ value; startpos; _ } : Syntax.Expr.t) =
  match value with
  | Syntax.Expr.Var string -> ok (Syntax.Tree.Leaf string)
  | Syntax.Expr.Tuple [ exp ] -> syntax_loc exp
  | Syntax.Expr.Tuple (_ :: _ :: _ as exps) ->
      let+ locs = Result.List.map syntax_loc exps in
      Syntax.Tree.Node locs
  | _ -> error_pos startpos "location expected"


let rec typed_type types pos (typ : Syntax.Stmt.typ) =
  match typ with
  | Syntax.Tree.Leaf Syntax.Stmt.Int -> ok Type.int
  | Syntax.Tree.Leaf (Syntax.Stmt.Name name) -> (
      match String.Map.find_opt name types with
      | Some ty -> ok ty
      | None -> unknown pos "type" name)
  | Syntax.Tree.Node l ->
      let+ l = Result.List.map (typed_type types pos) l in
      Type.tuple l


let rec typed_stmt types sigs named rettyp ctx toplevel lst
    ({ value; startpos; _ } as syntax : Syntax.Stmt.t) =
  match value with
  | Syntax.Stmt.Decl (typ, loc, exp) -> (
      if not toplevel then error_pos startpos "non top-level declaration"
      else
        let* typ = typed_type types startpos typ in
        let* tree = syntax_loc loc in
        (* Typed before the new variables are in scope: with top-level
           definitions only, every variable is written before being read. *)
        let* texp, te = typed_expr sigs ctx exp in
        match Syntax.Tree.unify tree typ with
        | None ->
            error_pos startpos "cannot unify %a with type %a" pp_syntax_loc tree
              Type.pp typ
        | Some list ->
            let* ctx =
              Result.List.fold_left_collect
                (fun ctx (string, typ) ->
                  if String.equal string "_" then ok ctx
                  else if String.Map.mem string ctx then
                    error_pos startpos "variable %s is already defined" string
                  else ok (String.Map.add string (named string, typ) ctx))
                ctx list
            in
            (* The declared type also constrains the components bound to _. *)
            if not (Type.equal typ te) then
              type_error startpos Expr.pp texp Type.pp te Type.pp typ
            else
              typed_stmt types sigs named rettyp ctx false lst
                Syntax.{ syntax with value = Stmt.Assign (loc, exp) })
  | Syntax.Stmt.Assign (loc, exp) ->
      let* loc = syntax_loc loc in
      let* exp, te = typed_expr sigs ctx exp in
      let* loc, tl = typed_loc startpos ctx loc te in
      if not (Type.equal tl te) then
        type_error startpos Expr.pp exp Type.pp te Type.pp tl
      else if conflict (groups loc exp) then
        error_pos startpos "variable assigned then read in the same assignment"
      else ok (ctx, Stmt.(make startpos (Assign (loc, exp))) :: lst)
  | Syntax.Stmt.Do (string, exps) -> (
      let* either = typed_call sigs ctx startpos string exps in
      match either with
      | Either.Left (_, rettyp) ->
          type_error startpos Format.pp_print_string string Type.pp rettyp
            Type.pp_opt None
      | Either.Right stmt -> ok (ctx, Stmt.(make startpos stmt) :: lst))
  | Syntax.Stmt.Assert cnd ->
      let* cnd = typed_cond sigs ctx cnd in
      ok (ctx, Stmt.(make startpos (Assert cnd)) :: lst)
  | Syntax.Stmt.Return _ when not toplevel ->
      error_pos startpos "non top-level return"
  | Syntax.Stmt.Return exp -> (
      let* exp, typ =
        match exp with
        | None -> ok (None, None)
        | Some exp ->
            let* exp, ty = typed_expr sigs ctx exp in
            ok (Some exp, Some ty)
      in
      match (exp, typ, rettyp) with
      | None, None, None -> ok (ctx, Stmt.(make startpos (Return None)) :: lst)
      | Some exp, Some ty, Some typ when Type.equal ty typ ->
          ok (ctx, Stmt.(make startpos (Return (Some exp))) :: lst)
      | _, _, _ ->
          type_error startpos Format.pp_print_string "return value" Type.pp_opt
            typ Type.pp_opt rettyp)
  | Syntax.Stmt.If (cnd, blk1, blk2) ->
      let* cnd = typed_cond sigs ctx cnd in
      let* ctx, blk1 = typed_block types sigs named rettyp ctx false blk1 in
      let* ctx, blk2 = typed_block types sigs named rettyp ctx false blk2 in
      ok (ctx, Stmt.(make startpos (If (cnd, blk1, blk2))) :: lst)
  | Syntax.Stmt.While (cnd, blk) ->
      let* cnd = typed_cond sigs ctx cnd in
      let* ctx, blk = typed_block types sigs named rettyp ctx false blk in
      ok (ctx, Stmt.(make startpos (While (cnd, blk))) :: lst)


and typed_block types sigs named rettyp ctx toplevel list =
  let+ ctx, result =
    Result.List.fold_left_collect
      (fun (ctx, result) ({ startpos; _ } as stmt : Syntax.Stmt.t) ->
        match result with
        | { Stmt.stmt_desc = Stmt.Return _; _ } :: _ ->
            error_pos startpos "unreachable statement"
        | _ -> typed_stmt types sigs named rettyp ctx toplevel result stmt)
      (ctx, []) list
  in
  (ctx, List.rev result)


let typed_func types sigs ({ value; startpos; _ } : Syntax.Func.t) =
  let func_pos = startpos in
  let func_name = value.func_name in
  let* func_rettyp =
    match value.func_rettyp with
    | None -> ok None
    | Some typ ->
        let+ typ = typed_type types startpos typ in
        Some typ
  in
  let named = Var.named ~func:func_name in
  let* ctx, func_params =
    Result.List.fold_left_map
      (fun ctx (ty, s) ->
        if String.equal s "_" then error_pos startpos "invalid parameter name _"
        else if String.Map.mem s ctx then
          error_pos startpos "parameter %s is already defined" s
        else
          let+ ty = typed_type types startpos ty in
          let v = named s in
          (String.Map.add s (v, ty) ctx, (v, ty)))
      String.Map.empty value.func_params
  in
  let* ctx, func_body =
    typed_block types sigs named func_rettyp ctx true value.func_body
  in
  let func_locals =
    List.fold_left
      (fun ctx (_, s) -> String.Map.remove s ctx)
      ctx value.func_params
    |> String.Map.bindings |> List.map snd
  in
  let returns =
    match List.rev func_body with
    | { Stmt.stmt_desc = Stmt.Return _; _ } :: _ -> true
    | _ -> false
  in
  if func_rettyp <> None && not returns then
    error_pos startpos "end of function %s reached without returning" func_name
  else
    ok
      Func.
        {
          func_pos;
          func_name;
          func_rettyp;
          func_params;
          func_locals;
          func_body;
        }


let typed_toplevels list =
  let* _, _, funcs =
    Result.List.fold_left_collect
      (fun (types, sigs, funcs) (toplevel : Syntax.toplevel) ->
        match toplevel with
        | Syntax.Typedef { value = name, typ; startpos; _ } ->
            if String.Map.mem name types then
              error_pos startpos "type %s is already defined" name
            else
              let+ typ = typed_type types startpos typ in
              (String.Map.add name typ types, sigs, funcs)
        | Syntax.Function ({ value; startpos; _ } as func) ->
            if String.Map.mem value.func_name sigs then
              error_pos startpos "function %s is already defined"
                value.func_name
            else
              let+ func = typed_func types sigs func in
              ( types,
                String.Map.add func.func_name
                  (func.func_rettyp, List.map snd func.func_params)
                  sigs,
                func :: funcs ))
      (String.Map.empty, String.Map.empty, [])
      list
  in
  ok (List.rev funcs)


let typed_program file list =
  let error_file msg =
    match file with
    | "" -> error (String.capitalize_ascii msg)
    | str -> error_format "File %s: %s" str msg
  in
  let* funcs = typed_toplevels list in
  match
    List.find_opt (fun func -> String.equal func.Func.func_name "main") funcs
  with
  | None -> error_file "no main function."
  | Some func ->
      if func.Func.func_rettyp = None && List.length func.Func.func_params = 0
      then ok { environment = Env.make funcs; entrypoint = "main" }
      else error_file "main function must have no parameters and return void."


let parse_program file =
  In_channel.with_open_text file (fun channel ->
      let lexbuf = Lexing.from_channel channel in
      Lexing.set_filename lexbuf file;
      try
        let syntax = Parser.main Lexer.token lexbuf in
        typed_program file syntax
      with
      | Lexer.Error (pos, msg) -> error_pos pos "%s" msg
      | Parser.Error -> error_pos (Lexing.lexeme_start_p lexbuf) "syntax error")


let parse_program file =
  match parse_program file with
  | Ok program -> program
  | Error error ->
      prerr_endline error;
      failwith file
