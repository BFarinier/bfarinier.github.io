open Core

module type COND = sig
  type expr

  type comp = Syntax.Cond.comp = Eq | Nq | Le | Lt | Ge | Gt

  type t = Atom of comp * expr * expr | And of t * t | Or of t * t

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit

  val atom : comp -> expr -> expr -> t

  val conj : t -> t -> t

  val disj : t -> t -> t

  val not : t -> t

  module Debug : DATATYPE with type t = t
end

include COND with type expr := Expr.t

val string_of_comp : comp -> string

module Make (Expr : DATATYPE) : COND with type expr := Expr.t
