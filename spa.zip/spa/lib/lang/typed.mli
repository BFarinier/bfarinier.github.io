open Core

module Type : sig
  type t = unit Syntax.Tree.t

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val pp_opt : Format.formatter -> t option -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

  val int : t

  val tuple : t list -> t

  val is_int : t -> bool
end

module Loc : sig
  type t = (Var.t * Type.t) Syntax.Tree.t

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

  val var : Var.t -> Type.t -> t

  val tuple : t list -> t
end

module Expr : sig
  type unop = Syntax.Expr.unop = Neg

  type bnop = Syntax.Expr.bnop = Add | Sub | Mul

  val string_of_unop : unop -> string

  val string_of_bnop : bnop -> string

  type t =
    | Cst of int
    | Var of Var.t
    | Unop of unop * t
    | Bnop of bnop * t * t
    | Rand of int * int
    | Call of string * t list
    | Tuple of t list

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

  val cst : int -> t

  val var : Var.t -> t

  val unop : unop -> t -> t

  val bnop : bnop -> t -> t -> t

  val rand : int -> int -> t

  val call : string -> t list -> t

  val tuple : t list -> t
end

module Cond : sig
  type comp = Syntax.Cond.comp = Eq | Nq | Le | Lt | Ge | Gt

  type t = Atom of comp * Expr.t * Expr.t | And of t * t | Or of t * t

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

  val atom : comp -> Expr.t -> Expr.t -> t

  val conj : t -> t -> t

  val disj : t -> t -> t

  val not : t -> t
end

module Stmt : sig
  type t = { stmt_pos : Position.t; stmt_desc : desc }

  and desc =
    | Assert of Cond.t
    | Assign of Loc.t * Expr.t
    | If of Cond.t * block * block
    | While of Cond.t * block
    | Print of Expr.t
    | Do of string * Expr.t list
    | Return of Expr.t option

  and block = t list

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]
end

module Func : sig
  type t = {
    func_pos : Position.t;
    func_name : string;
    func_rettyp : Type.t option;
    func_params : (Var.t * Type.t) list;
    func_locals : (Var.t * Type.t) list;
    func_body : Stmt.block;
  }

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]
end

module Env : sig
  type t

  val make : Func.t list -> t

  val find : string -> t -> Func.t

  val functions : t -> Func.t list
end

type program = { environment : Env.t; entrypoint : string }

val pp : Format.formatter -> program -> unit

val parse_program : string -> program
