open Core

type t = Lexing.position

val equal : t -> t -> bool

val compare : t -> t -> int

val pp : Format.formatter -> t -> unit

val pp_with_offset : Format.formatter -> t -> unit

val debug : Format.formatter -> t -> unit

module Map : Map.S with type key = t

module Set : Set.S with type elt = t
