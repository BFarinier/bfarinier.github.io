module V = Var.Debug

module Expr = struct
  include Expr

  let pp fmt t = pp_qualified fmt t
end

module E = Expr.Debug

module Cond = struct
  include Cond

  let pp fmt t = pp_with Expr.pp fmt t
end

module C = Cond.Debug

module Stmt = struct
  module Internal = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of V.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Pp.pp_assert Cond.pp fmt cd
    | Assign (v, ex) -> Pp.pp_assign Var.pp_qualified Expr.pp fmt v ex
    | If (cd, bl, []) -> Pp.pp_if_then Cond.pp pp_block fmt cd bl
    | If (cd, bl1, bl2) -> Pp.pp_if_then_else Cond.pp pp_block fmt cd bl1 bl2
    | While (cd, bl) -> Pp.pp_while Cond.pp pp_block fmt cd bl
    | Print ex -> Pp.pp_print Expr.pp fmt ex


  and pp_block fmt lst = Pp.pp_block pp fmt lst

  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

type program = { vars : Var.t list; body : Stmt.block }

let pp fmt { body; _ } = Stmt.pp_block fmt body

(******************************************************************************)

let rec inlined_stmt env rets ({ stmt_pos; stmt_desc } : Flattened.Stmt.t) =
  match stmt_desc with
  | Flattened.Stmt.Assert cnd -> [ Stmt.(make stmt_pos (Assert cnd)) ]
  | Flattened.Stmt.Assign (var, exp) ->
      [ Stmt.(make stmt_pos (Assign (var, exp))) ]
  | Flattened.Stmt.If (cnd, blk1, blk2) ->
      let blk1 = inlined_block env rets blk1 in
      let blk2 = inlined_block env rets blk2 in
      [ Stmt.(make stmt_pos (If (cnd, blk1, blk2))) ]
  | Flattened.Stmt.While (cnd, blk) ->
      let blk = inlined_block env rets blk in
      [ Stmt.(make stmt_pos (While (cnd, blk))) ]
  | Flattened.Stmt.Print exp -> [ Stmt.(make stmt_pos (Print exp)) ]
  | Flattened.Stmt.Call (vars, string, exps) ->
      inlined_func env vars (Flattened.Env.find string env) exps
  (* A return always ends its function (checked by Typed): binding the
     results is enough. *)
  | Flattened.Stmt.Return exps ->
      List.map2
        (fun var exp -> Stmt.(make stmt_pos (Assign (var, exp))))
        rets exps


and inlined_block env rets blk = List.concat_map (inlined_stmt env rets) blk

(* A function only calls previously defined ones: calls to the same function
   never overlap, so its variables are reused without renaming. Locals need
   no initialization, being written before read. *)
and inlined_func env vars func exps =
  let assign var exp =
    Stmt.(make func.Flattened.Func.func_pos (Assign (var, exp)))
  in
  List.map2 assign func.Flattened.Func.func_params exps
  @ inlined_block env vars func.Flattened.Func.func_body


(* Every variable is written before being read: the assigned ones are all the
   program variables. *)
let rec assigned set blk =
  List.fold_left
    (fun set ({ Stmt.stmt_desc; _ } : Stmt.t) ->
      match stmt_desc with
      | Stmt.Assign (var, _) -> Var.Set.add var set
      | Stmt.If (_, blk1, blk2) -> assigned (assigned set blk1) blk2
      | Stmt.While (_, blk) -> assigned set blk
      | Stmt.Assert _ | Stmt.Print _ -> set)
    set blk


let inlined_program ({ environment; entrypoint } : Flattened.program) =
  let func = Flattened.Env.find entrypoint environment in
  let body = inlined_func environment [] func [] in
  { vars = Var.Set.elements (assigned Var.Set.empty body); body }


let parse_program file = inlined_program (Flattened.parse_program file)
