open Core
open Inlined

exception AssertionFailure of string

(** Raise an assertion failure for the given source position. *)
let assertion_failure pos =
  raise (AssertionFailure (Format.asprintf "%a" Position.pp pos))


(** Read an integer within the given bounds. Ask the user for a value. On error,
    pick a pseudorandom value in the same bounds. Return the selected integer.
*)
let not_so_random lo hi =
  assert (lo <= hi);
  Printf.printf "Enter a value between %i and %i (incl.): " lo hi;
  let i = try int_of_string (read_line ()) with _ -> max_int in
  if i < lo || i > hi then (
    let i = Random.int_in_range ~min:lo ~max:hi in
    Printf.printf "Invalid value, continuing with %i.\n%!" i;
    i)
  else i


(** Print the given arbitrary-precision integer followed by a newline. *)
let print i = print_endline (Z.to_string i)

(******************************************************************************)

type state = Z.t Var.Map.t

let rec eval_expr (stt : state) (expr : Expr.t) : Z.t =
  match expr with
  | Expr.Cst int -> Z.of_int int
  | Expr.Var var -> Var.Map.find var stt
  | Expr.Unop (u, exp) ->
      (match u with
      | Expr.Neg -> Z.neg)
        (eval_expr stt exp)
  | Expr.Bnop (b, exp1, exp2) ->
      (match b with
      | Expr.Add -> Z.add
      | Expr.Sub -> Z.sub
      | Expr.Mul -> Z.mul)
        (eval_expr stt exp1) (eval_expr stt exp2)
  | Expr.Rand (lo, hi) -> Z.of_int (not_so_random lo hi)


let rec eval_cond (stt : state) (cond : Cond.t) : bool =
  match cond with
  | Inlined.Cond.Atom (c, exp1, exp2) ->
      (match c with
      | Syntax.Cond.Eq -> ( = )
      | Syntax.Cond.Nq -> ( <> )
      | Syntax.Cond.Le -> ( <= )
      | Syntax.Cond.Lt -> ( < )
      | Syntax.Cond.Ge -> ( >= )
      | Syntax.Cond.Gt -> ( > ))
        (eval_expr stt exp1) (eval_expr stt exp2)
  | Inlined.Cond.And (cnd1, cnd2) -> eval_cond stt cnd1 && eval_cond stt cnd2
  | Inlined.Cond.Or (cnd1, cnd2) -> eval_cond stt cnd1 || eval_cond stt cnd2


let rec eval_stmt (stt : state) (stmt : Stmt.t) : state =
  match stmt.stmt_desc with
  | Inlined.Stmt.Assert cnd ->
      if eval_cond stt cnd then stt else assertion_failure stmt.stmt_pos
  | Inlined.Stmt.Assign (var, exp) -> Var.Map.add var (eval_expr stt exp) stt
  | Inlined.Stmt.If (cnd, blk1, blk2) ->
      if eval_cond stt cnd then eval_block stt blk1 else eval_block stt blk2
  | Inlined.Stmt.While (cnd, blk) ->
      if eval_cond stt cnd then eval_stmt (eval_block stt blk) stmt else stt
  | Inlined.Stmt.Print exp ->
      print (eval_expr stt exp);
      stt


and eval_block (stt : state) (block : Stmt.block) : state =
  List.fold_left eval_stmt stt block


(******************************************************************************)

let eval (program : program) : unit =
  (* Evaluate the program body with an empty initial state
     and discard the returned state. *)
  ignore (eval_block Var.Map.empty program.body)
