open Core

type t

val equal : t -> t -> bool

val compare : t -> t -> int

val named : ?func:string -> string -> t

val fresh : ?func:string -> unit -> t

val name : t -> string

val sub : t -> string -> t

val pp : Format.formatter -> t -> unit

val pp_qualified : Format.formatter -> t -> unit

val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

val serialize : t -> string

module Map : Map.S with type key = t

module Set : Set.S with type elt = t

module Debug : DATATYPE with type t = t
