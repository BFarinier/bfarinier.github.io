open Core

type unop = Syntax.Expr.unop = Neg

type bnop = Syntax.Expr.bnop = Add | Sub | Mul

val string_of_unop : unop -> string

val string_of_bnop : bnop -> string

type t =
  | Cst of int
  | Var of Var.t
  | Unop of unop * t
  | Bnop of bnop * t * t
  | Rand of int * int

val equal : t -> t -> bool

val compare : t -> t -> int

val pp : Format.formatter -> t -> unit

val debug : Format.formatter -> t -> unit [@@ocaml.toplevel_printer]

val cst : int -> t

val var : Var.t -> t

val unop : unop -> t -> t

val bnop : bnop -> t -> t -> t

val rand : int -> int -> t

module Debug : DATATYPE with type t = t
