open Core
module V = Var.Debug
module Expr = Expr
module E = Expr.Debug
module Cond = Cond
module C = Cond.Debug

module Stmt = struct
  module Debug = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of V.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
      | Call of V.t list * string * E.t list
      | Return of E.t list
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]

    let debug fmt t = pp fmt t
  end

  include Debug

  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Pp.pp_assert Cond.pp fmt cd
    | Assign (v, ex) -> Pp.pp_assign Var.pp Expr.pp fmt v ex
    | If (cd, bl, []) -> Pp.pp_if_then Cond.pp pp_block fmt cd bl
    | If (cd, bl1, bl2) -> Pp.pp_if_then_else Cond.pp pp_block fmt cd bl1 bl2
    | While (cd, bl) -> Pp.pp_while Cond.pp pp_block fmt cd bl
    | Print ex -> Pp.pp_print Expr.pp fmt ex
    | Call ([], s, exs) -> Pp.pp_do Expr.pp fmt s exs
    | Call (ls, s, exs) ->
        Pp.pp_assign (Pp.pp_tuple Var.pp)
          (fun fmt (s, exs) -> Pp.pp_call Expr.pp fmt s exs)
          fmt ls (s, exs)
    | Return [] -> Pp.pp_return_none fmt ()
    | Return ls -> Pp.pp_return_some (Pp.pp_tuple Expr.pp) fmt ls


  and pp_block fmt lst = Pp.pp_block pp fmt lst

  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

module S = Stmt.Debug

module Func = struct
  module Internal = struct
    type t = {
      func_pos : Position.t; [@opaque]
      func_name : string;
      func_rettyp : int;
      func_params : V.t list;
      func_locals : V.t list;
      func_body : S.block;
    }
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let pp_rettyp fmt t =
    if t <= 0 then Format.pp_print_string fmt "void"
    else if t = 1 then Format.pp_print_string fmt "int"
    else
      Pp.pp_tuple_brack Format.pp_print_string fmt
        (List.init t (fun _ -> "int"))


  let pp_typed_var fmt v = Format.fprintf fmt "int %a" Var.pp v

  let pp fmt { func_name; func_rettyp; func_params; func_locals; func_body; _ }
      =
    Pp.pp_func pp_rettyp pp_typed_var Stmt.pp_block fmt func_name func_rettyp
      func_params func_locals func_body
end

module Env = struct
  type t = (string * Func.t) list

  let make list = List.map (fun func -> (func.Func.func_name, func)) list

  let find string t = List.assoc string t

  let functions t = List.map snd t
end

type program = { environment : Env.t; entrypoint : string }

let pp fmt { environment; _ } =
  Pp.pp_env Func.pp fmt (Env.functions environment)


(******************************************************************************)

let ensure_single l =
  match l with
  | [ x ] -> x
  | _ -> assert false


let flattened_typopt opt =
  match opt with
  | None -> 0
  | Some ty -> List.length (Syntax.Tree.flatten ty)


let rec flattened_var (var, ty) =
  match ty with
  | Syntax.Tree.Leaf _ -> [ var ]
  | Syntax.Tree.Node l ->
      List.flatten
        (List.mapi
           (fun i ty -> flattened_var (Var.sub var (string_of_int i), ty))
           l)


let flattened_loc fresh ctx (loc : Typed.Loc.t) =
  List.concat_map
    (fun (var, typ) ->
      if Var.equal var Typed.Loc.wildcard then
        List.map (fun _ -> fresh ()) (Syntax.Tree.flatten typ)
      else Var.Map.find var ctx)
    (Syntax.Tree.flatten loc)


(* Calls are hoisted out of expressions: [lst] accumulates, in reverse
   order, the calls to execute first, whose results are bound to fresh
   temporaries. *)
let rec flattened_expr fresh sigs pos ctx lst (expr : Typed.Expr.t) =
  match expr with
  | Typed.Expr.Cst int -> (lst, [ Expr.cst int ])
  | Typed.Expr.Var var -> (lst, List.map Expr.var (Var.Map.find var ctx))
  | Typed.Expr.Unop (u, exp) ->
      let lst, exp = flattened_expr fresh sigs pos ctx lst exp in
      let exp = ensure_single exp in
      (lst, [ Expr.unop u exp ])
  | Typed.Expr.Bnop (b, exp1, exp2) ->
      let lst, exp1 = flattened_expr fresh sigs pos ctx lst exp1 in
      let lst, exp2 = flattened_expr fresh sigs pos ctx lst exp2 in
      let exp1 = ensure_single exp1 in
      let exp2 = ensure_single exp2 in
      (lst, [ Expr.bnop b exp1 exp2 ])
  | Typed.Expr.Rand (lo, hi) -> (lst, [ Expr.rand lo hi ])
  | Typed.Expr.Call (string, exps) ->
      let rettyp = String.Map.find string sigs in
      let vars = List.init rettyp (fun _ -> fresh ()) in
      ( flattened_call fresh sigs pos ctx lst vars string exps,
        List.map Expr.var vars )
  | Typed.Expr.Tuple exps ->
      let lst, exps =
        List.fold_left_map (flattened_expr fresh sigs pos ctx) lst exps
      in
      (lst, List.flatten exps)


and flattened_call fresh sigs pos ctx lst vars string exps =
  let lst, exps =
    List.fold_left_map (flattened_expr fresh sigs pos ctx) lst exps
  in
  Stmt.(make pos (Call (vars, string, List.flatten exps))) :: lst


(* Conditions are call-free (checked by Typed): nothing to hoist. *)
let flattened_pure fresh sigs pos ctx (expr : Typed.Expr.t) =
  match flattened_expr fresh sigs pos ctx [] expr with
  | [], [ exp ] -> exp
  | _ -> assert false


let rec flattened_cond fresh sigs pos ctx (cond : Typed.Cond.t) =
  match cond with
  | Typed.Cond.Atom (c, exp1, exp2) ->
      let exp1 = flattened_pure fresh sigs pos ctx exp1 in
      let exp2 = flattened_pure fresh sigs pos ctx exp2 in
      Cond.atom c exp1 exp2
  | Typed.Cond.And (cnd1, cnd2) ->
      let cnd1 = flattened_cond fresh sigs pos ctx cnd1 in
      let cnd2 = flattened_cond fresh sigs pos ctx cnd2 in
      Cond.conj cnd1 cnd2
  | Typed.Cond.Or (cnd1, cnd2) ->
      let cnd1 = flattened_cond fresh sigs pos ctx cnd1 in
      let cnd2 = flattened_cond fresh sigs pos ctx cnd2 in
      Cond.disj cnd1 cnd2


let rec flattened_stmt fresh sigs ctx lst
    ({ stmt_pos; stmt_desc } : Typed.Stmt.t) =
  match stmt_desc with
  | Typed.Stmt.Assert cnd ->
      let cnd = flattened_cond fresh sigs stmt_pos ctx cnd in
      Stmt.(make stmt_pos (Assert cnd)) :: lst
  | Typed.Stmt.Assign (loc, exp) -> (
      let var = flattened_loc fresh ctx loc in
      match exp with
      | Call (string, exps) ->
          flattened_call fresh sigs stmt_pos ctx lst var string exps
      | exp ->
          let lst, exp = flattened_expr fresh sigs stmt_pos ctx lst exp in
          List.rev_append
            (List.map2
               (fun var exp -> Stmt.(make stmt_pos (Assign (var, exp))))
               var exp)
            lst)
  | Typed.Stmt.If (cnd, blk1, blk2) ->
      let cnd = flattened_cond fresh sigs stmt_pos ctx cnd in
      let blk1 = flattened_block fresh sigs ctx blk1 in
      let blk2 = flattened_block fresh sigs ctx blk2 in
      Stmt.(make stmt_pos (If (cnd, blk1, blk2))) :: lst
  | Typed.Stmt.While (cnd, blk) ->
      let cnd = flattened_cond fresh sigs stmt_pos ctx cnd in
      let blk = flattened_block fresh sigs ctx blk in
      Stmt.(make stmt_pos (While (cnd, blk))) :: lst
  | Typed.Stmt.Print exp ->
      let lst, exp = flattened_expr fresh sigs stmt_pos ctx lst exp in
      let exp = ensure_single exp in
      Stmt.(make stmt_pos (Print exp)) :: lst
  | Typed.Stmt.Do (string, exps) ->
      flattened_call fresh sigs stmt_pos ctx lst [] string exps
  | Typed.Stmt.Return None -> Stmt.(make stmt_pos (Return [])) :: lst
  | Typed.Stmt.Return (Some exp) ->
      let lst, exp = flattened_expr fresh sigs stmt_pos ctx lst exp in
      Stmt.(make stmt_pos (Return exp)) :: lst


and flattened_block fresh sigs ctx blk =
  List.rev (List.fold_left (flattened_stmt fresh sigs ctx) [] blk)


let flattened_func sigs (func : Typed.Func.t) =
  let func_pos = func.Typed.Func.func_pos in
  let func_name = func.Typed.Func.func_name in
  let func_rettyp = flattened_typopt func.Typed.Func.func_rettyp in
  let temps = ref Var.Set.empty in
  let fresh =
    let fresh = Var.fresh ~func:func_name in
    fun () ->
      let var = fresh () in
      temps := Var.Set.add var !temps;
      var
  in
  let add ctx ((var, _) as var_ty) =
    let vars = flattened_var var_ty in
    (Var.Map.add var vars ctx, vars)
  in
  let ctx, func_params =
    List.fold_left_map add Var.Map.empty func.Typed.Func.func_params
  in
  let ctx, func_locals =
    List.fold_left_map add ctx func.Typed.Func.func_locals
  in
  let func_body = flattened_block fresh sigs ctx func.Typed.Func.func_body in
  let func_params = List.flatten func_params in
  let func_locals =
    Var.Set.elements
      (Var.Set.union (Var.Set.of_list (List.flatten func_locals)) !temps)
  in
  ( String.Map.add func_name func_rettyp sigs,
    Func.
      { func_pos; func_name; func_rettyp; func_params; func_locals; func_body }
  )


let flattened_funcs list =
  let _, list = List.fold_left_map flattened_func String.Map.empty list in
  list


let flattened_program ({ environment; entrypoint } : Typed.program) =
  let environment =
    Env.make (flattened_funcs (Typed.Env.functions environment))
  in
  { environment; entrypoint }


let parse_program file = flattened_program (Typed.parse_program file)
