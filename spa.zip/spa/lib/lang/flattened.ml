open Core
module V = Var.Debug
module Expr = Expr
module E = Expr.Debug
module Cond = Cond
module C = Cond.Debug

module Stmt = struct
  module Debug = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of V.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
      | Call of V.t list * string * E.t list
      | Return of E.t list
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]

    let debug fmt t = pp fmt t
  end

  include Debug

  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Pp.pp_assert Cond.pp fmt cd
    | Assign (v, ex) -> Pp.pp_assign Var.pp Expr.pp fmt v ex
    | If (cd, bl, []) -> Pp.pp_if_then Cond.pp pp_block fmt cd bl
    | If (cd, bl1, bl2) -> Pp.pp_if_then_else Cond.pp pp_block fmt cd bl1 bl2
    | While (cd, bl) -> Pp.pp_while Cond.pp pp_block fmt cd bl
    | Print ex -> Pp.pp_print Expr.pp fmt ex
    | Call ([], s, exs) -> Pp.pp_do Expr.pp fmt s exs
    | Call (ls, s, exs) ->
        Pp.pp_assign (Pp.pp_tuple Var.pp)
          (fun fmt (s, exs) -> Pp.pp_call Expr.pp fmt s exs)
          fmt ls (s, exs)
    | Return [] -> Pp.pp_return_none fmt ()
    | Return ls -> Pp.pp_return_some (Pp.pp_tuple Expr.pp) fmt ls


  and pp_block fmt lst = Pp.pp_block pp fmt lst

  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

module S = Stmt.Debug

module Func = struct
  module Internal = struct
    type t = {
      func_pos : Position.t; [@opaque]
      func_name : string;
      func_rettyp : int;
      func_params : V.t list;
      func_locals : V.t list;
      func_body : S.block;
    }
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let pp_rettyp fmt t =
    if t <= 0 then Format.pp_print_string fmt "void"
    else if t = 1 then Format.pp_print_string fmt "int"
    else
      Pp.pp_tuple_brack Format.pp_print_string fmt
        (List.init t (fun _ -> "int"))


  let pp_typed_var fmt v = Format.fprintf fmt "int %a" Var.pp v

  let pp fmt { func_name; func_rettyp; func_params; func_locals; func_body; _ }
      =
    Pp.pp_func pp_rettyp pp_typed_var Stmt.pp_block fmt func_name func_rettyp
      func_params func_locals func_body
end

module Env = struct
  type t = (string * Func.t) list

  let make list = List.map (fun func -> (func.Func.func_name, func)) list

  let find string t = List.assoc string t

  let functions t = List.map snd t
end

type program = { environment : Env.t; entrypoint : string }

let pp fmt { environment; _ } =
  Pp.pp_env Func.pp fmt (Env.functions environment)


(******************************************************************************)

let ensure_single l =
  match l with
  | [ x ] -> x
  | _ -> assert false


let flattened_typopt opt =
  match opt with
  | None -> 0
  | Some ty -> List.length (Syntax.Tree.flatten ty)


let rec flattened_var (var, ty) =
  match ty with
  | Syntax.Tree.Leaf _ -> [ var ]
  | Syntax.Tree.Node l ->
      List.flatten
        (List.mapi
           (fun i ty -> flattened_var (Var.sub var (string_of_int i), ty))
           l)


let flattened_loc (loc : Typed.Loc.t) = List.map fst (Syntax.Tree.flatten loc)

let rec flattened_expr fresh sigs pos ((ctx, _) as ctx_lst)
    (expr : Typed.Expr.t) =
  match expr with
  | Typed.Expr.Cst int -> (ctx_lst, [ Expr.cst int ])
  | Typed.Expr.Var var -> (ctx_lst, List.map Expr.var (Var.Map.find var ctx))
  | Typed.Expr.Unop (u, exp) ->
      let ctx_lst, exp = flattened_expr fresh sigs pos ctx_lst exp in
      let exp = ensure_single exp in
      (ctx_lst, [ Expr.unop u exp ])
  | Typed.Expr.Bnop (b, exp1, exp2) ->
      let ctx_lst, exp1 = flattened_expr fresh sigs pos ctx_lst exp1 in
      let ctx_lst, exp2 = flattened_expr fresh sigs pos ctx_lst exp2 in
      let exp1 = ensure_single exp1 in
      let exp2 = ensure_single exp2 in
      (ctx_lst, [ Expr.bnop b exp1 exp2 ])
  | Typed.Expr.Rand (lo, hi) -> (ctx_lst, [ Expr.rand lo hi ])
  | Typed.Expr.Call (string, exps) ->
      let rettyp = String.Map.find string sigs in
      let vars = List.init rettyp (fun _ -> fresh ()) in
      let (ctx, lst), exps =
        List.fold_left_map (flattened_expr fresh sigs pos) ctx_lst exps
      in
      let ctx =
        List.fold_left (fun ctx var -> Var.Map.add var [ var ] ctx) ctx vars
      in
      ( (ctx, Stmt.make pos (Call (vars, string, List.flatten exps)) :: lst),
        List.map Expr.var vars )
  | Typed.Expr.Tuple exps ->
      let ctx_lst, exps =
        List.fold_left_map (flattened_expr fresh sigs pos) ctx_lst exps
      in
      (ctx_lst, List.flatten exps)


let rec flattened_cond fresh sigs pos ctx_lst (cond : Typed.Cond.t) =
  match cond with
  | Typed.Cond.Atom (c, exp1, exp2) ->
      let ctx_lst, exp1 = flattened_expr fresh sigs pos ctx_lst exp1 in
      let ctx_lst, exp2 = flattened_expr fresh sigs pos ctx_lst exp2 in
      let exp1 = ensure_single exp1 in
      let exp2 = ensure_single exp2 in
      (ctx_lst, Cond.atom c exp1 exp2)
  | Typed.Cond.And (cnd1, cnd2) ->
      let ctx_lst, cnd1 = flattened_cond fresh sigs pos ctx_lst cnd1 in
      let ctx_lst, cnd2 = flattened_cond fresh sigs pos ctx_lst cnd2 in
      (ctx_lst, Cond.conj cnd1 cnd2)
  | Typed.Cond.Or (cnd1, cnd2) ->
      let ctx_lst, cnd1 = flattened_cond fresh sigs pos ctx_lst cnd1 in
      let ctx_lst, cnd2 = flattened_cond fresh sigs pos ctx_lst cnd2 in
      (ctx_lst, Cond.disj cnd1 cnd2)


let rec flattened_stmt fresh sigs ((ctx, lst) as ctx_lst)
    ({ stmt_pos; stmt_desc } : Typed.Stmt.t) =
  match stmt_desc with
  | Typed.Stmt.Assert cnd ->
      let (ctx, lst), cnd = flattened_cond fresh sigs stmt_pos ctx_lst cnd in
      (ctx, Stmt.(make stmt_pos (Assert cnd)) :: lst)
  | Typed.Stmt.Assign (loc, exp) -> (
      let var =
        List.flatten
          (List.map (fun v -> Var.Map.find v ctx) (flattened_loc loc))
      in
      match exp with
      | Call (string, exps) ->
          let (ctx, lst), exps =
            List.fold_left_map (flattened_expr fresh sigs stmt_pos) ctx_lst exps
          in
          ( ctx,
            Stmt.(make stmt_pos (Call (var, string, List.flatten exps))) :: lst
          )
      | exp ->
          let (ctx, lst), exp =
            flattened_expr fresh sigs stmt_pos ctx_lst exp
          in
          ( ctx,
            List.rev_append
              (List.map2
                 (fun var exp -> Stmt.(make stmt_pos (Assign (var, exp))))
                 var exp)
              lst ))
  | Typed.Stmt.If (cnd, blk1, blk2) ->
      let (ctx, lst), cnd = flattened_cond fresh sigs stmt_pos ctx_lst cnd in
      let ctx, blk1 = flattened_block fresh sigs ctx blk1 in
      let ctx, blk2 = flattened_block fresh sigs ctx blk2 in
      (ctx, Stmt.(make stmt_pos (If (cnd, blk1, blk2))) :: lst)
  | Typed.Stmt.While (cnd, blk) ->
      let (ctx, l), cnd = flattened_cond fresh sigs stmt_pos (ctx, []) cnd in
      let ctx, blk = flattened_block fresh sigs ctx blk in
      (ctx, Stmt.(make stmt_pos (While (cnd, blk @ List.rev l))) :: (l @ lst))
  | Typed.Stmt.Print exp ->
      let (ctx, lst), exp = flattened_expr fresh sigs stmt_pos ctx_lst exp in
      let exp = ensure_single exp in
      (ctx, Stmt.(make stmt_pos (Print exp)) :: lst)
  | Typed.Stmt.Do (string, exps) ->
      let (ctx, lst), exps =
        List.fold_left_map (flattened_expr fresh sigs stmt_pos) ctx_lst exps
      in
      (ctx, Stmt.make stmt_pos (Call ([], string, List.flatten exps)) :: lst)
  | Typed.Stmt.Return None -> (ctx, Stmt.(make stmt_pos (Return [])) :: lst)
  | Typed.Stmt.Return (Some exp) ->
      let (ctx, lst), exp = flattened_expr fresh sigs stmt_pos ctx_lst exp in
      (ctx, Stmt.(make stmt_pos (Return exp)) :: lst)


and flattened_block fresh sigs ctx blk =
  let ctx, blk =
    List.fold_left
      (fun ctx_lst stmt -> flattened_stmt fresh sigs ctx_lst stmt)
      (ctx, []) blk
  in
  (ctx, List.rev blk)


let flattened_func sigs (func : Typed.Func.t) =
  let func_pos = func.Typed.Func.func_pos in
  let func_name = func.Typed.Func.func_name in
  let func_rettyp = flattened_typopt func.Typed.Func.func_rettyp in
  let ctx, func_params =
    List.fold_left_map
      (fun ctx ((var, _) as var_ty) ->
        let vars = flattened_var var_ty in
        (Var.Map.add var vars ctx, vars))
      Var.Map.empty func.Typed.Func.func_params
  in
  let func_params = List.flatten func_params in
  let ctx =
    List.fold_left
      (fun ctx ((var, _) as var_ty) ->
        let vars = flattened_var var_ty in
        Var.Map.add var vars ctx)
      ctx func.Typed.Func.func_locals
  in
  let ctx, func_body =
    flattened_block
      (Var.fresh ~func:func_name)
      sigs ctx func.Typed.Func.func_body
  in
  let func_locals =
    Var.Set.elements
      (List.fold_left
         (fun ctx var -> Var.Set.remove var ctx)
         (Var.Set.of_list (List.flatten (List.map snd (Var.Map.bindings ctx))))
         func_params)
  in
  ( String.Map.add func_name func_rettyp sigs,
    Func.
      { func_pos; func_name; func_rettyp; func_params; func_locals; func_body }
  )


let flattened_funcs list =
  let _, list = List.fold_left_map flattened_func String.Map.empty list in
  list


let flattened_program ({ environment; entrypoint } : Typed.program) =
  let environment =
    Env.make (flattened_funcs (Typed.Env.functions environment))
  in
  { environment; entrypoint }


let parse_program file = flattened_program (Typed.parse_program file)
