module Debug = struct
  type unop = Syntax.Expr.unop = Neg
  [@@deriving eq, ord, show { with_path = false }]

  type bnop = Syntax.Expr.bnop = Add | Sub | Mul
  [@@deriving eq, ord, show { with_path = false }]

  type t =
    | Cst of int
    | Var of Var.Debug.t
    | Unop of unop * t
    | Bnop of bnop * t * t
    | Rand of int * int
  [@@deriving eq, ord, show { with_path = false }]

  let debug fmt t = pp fmt t
end

include Debug

let string_of_unop u =
  match u with
  | Neg -> "-"


let string_of_bnop b =
  match b with
  | Add -> "+"
  | Sub -> "-"
  | Mul -> "*"


let rec pp fmt (t : t) =
  match t with
  | Cst i -> Format.pp_print_int fmt i
  | Var v -> Var.pp fmt v
  | Unop (u, ex) -> Pp.pp_unop pp_paren fmt (string_of_unop u) ex
  | Bnop (b, ex1, ex2) -> Pp.pp_bnop pp_paren fmt (string_of_bnop b) ex1 ex2
  | Rand (lo, hi) -> Pp.pp_rand fmt lo hi


and pp_paren fmt (t : t) =
  match t with
  | Cst i when i < 0 -> Pp.pp_paren pp fmt t
  | Cst _ | Var _ | Rand _ -> pp fmt t
  | Unop _ | Bnop _ -> Pp.pp_paren pp fmt t


let cst i = Cst i

let var v = Var v

let unop u t = Unop (u, t)

let bnop b t1 t2 = Bnop (b, t1, t2)

let rand lo hi = Rand (lo, hi)
