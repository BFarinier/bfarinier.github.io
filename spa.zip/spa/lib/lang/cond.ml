open Core

module Make (Expr : DATATYPE) = struct
  module Debug = struct
    module E = struct
      include Expr

      let pp fmt t = debug fmt t
    end

    type comp = Syntax.Cond.comp = Eq | Nq | Le | Lt | Ge | Gt
    [@@deriving eq, ord, show { with_path = false }]

    let string_of_comp c =
      match c with
      | Eq -> "=="
      | Nq -> "!="
      | Le -> "<="
      | Lt -> "<"
      | Ge -> ">="
      | Gt -> ">"


    type t = Atom of comp * E.t * E.t | And of t * t | Or of t * t
    [@@deriving eq, ord, show { with_path = false }]

    let debug fmt t = pp fmt t
  end

  include Debug

  let rec pp fmt (t : t) =
    match t with
    | Atom (a, e1, e2) -> Pp.pp_bnop Expr.pp fmt (string_of_comp a) e1 e2
    | And (c1, c2) -> Pp.pp_bnop pp_paren fmt "&&" c1 c2
    | Or (c1, c2) -> Pp.pp_bnop pp_paren fmt "||" c1 c2


  and pp_paren fmt (t : t) = Pp.pp_paren pp fmt t

  let atom a e1 e2 = Atom (a, e1, e2)

  let conj c1 c2 = And (c1, c2)

  let disj c1 c2 = Or (c1, c2)

  let rec not (t : t) =
    match t with
    | Atom (a, e1, e2) ->
        atom
          (match a with
          | Eq -> Nq
          | Nq -> Eq
          | Le -> Gt
          | Lt -> Ge
          | Ge -> Lt
          | Gt -> Le)
          e1 e2
    | And (c1, c2) -> disj (not c1) (not c2)
    | Or (c1, c2) -> conj (not c1) (not c2)
end

include Make (Expr)

module type COND = sig
  type expr

  type comp = Syntax.Cond.comp = Eq | Nq | Le | Lt | Ge | Gt

  type t = Atom of comp * expr * expr | And of t * t | Or of t * t

  val equal : t -> t -> bool

  val compare : t -> t -> int

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit

  val atom : comp -> expr -> expr -> t

  val conj : t -> t -> t

  val disj : t -> t -> t

  val not : t -> t

  module Debug : DATATYPE with type t = t
end
