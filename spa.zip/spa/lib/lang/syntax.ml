open Core

type 'a located = {
  startpos : Lexing.position;
  endpos : Lexing.position;
  value : 'a;
}

let pp_located f fmt x = f fmt x.value

module Tree = struct
  type 'a t = Leaf of 'a | Node of 'a t list
  [@@deriving eq, ord, show { with_path = false }]

  let rec flatten t =
    match t with
    | Leaf x -> [ x ]
    | Node l -> List.flatten (List.map flatten l)


  let rec unify s t =
    match (s, t) with
    | Leaf x, t -> [ (x, t) ]
    | Node k, Node l -> List.flatten (List.map2 unify k l)
    | Node _, _ -> invalid_arg "unify"


  let unify s t = try Some (unify s t) with Invalid_argument _ -> None
end

module Expr = struct
  type unop = Neg [@@deriving show { with_path = false }]

  type bnop = Add | Sub | Mul [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Cst of int
    | Var of string
    | Unop of unop * t
    | Bnop of bnop * t * t
    | Call of string * t list
    | Tuple of t list
  [@@deriving show { with_path = false }]
end

module Cond = struct
  type comp = Eq | Nq | Le | Lt | Ge | Gt
  [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Atom of comp * Expr.t * Expr.t
    | Not of t
    | And of t * t
    | Or of t * t
  [@@deriving show { with_path = false }]
end

module Stmt = struct
  type base = Int | Name of string [@@deriving show { with_path = false }]

  type typ = base Tree.t [@@deriving show { with_path = false }]

  type loc = string Tree.t [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Decl of typ * Expr.t * Expr.t
    | Assign of Expr.t * Expr.t
    | Do of string * Expr.t list
    | Assert of Cond.t
    | Return of Expr.t option
    | If of Cond.t * block * block
    | While of Cond.t * block
  [@@deriving show { with_path = false }]

  and block = t list

  let pp_block fmt t =
    Format.pp_print_list ~pp_sep:Format.pp_force_newline pp fmt t
end

module Func = struct
  type t = desc located [@@deriving show { with_path = false }]

  and desc = {
    func_name : string;
    func_rettyp : Stmt.typ option;
    func_params : (Stmt.typ * string) list;
    func_body : Stmt.block;
  }
  [@@deriving show { with_path = false }]
end

module Typedef = struct
  type t = (string * Stmt.typ) located [@@deriving show { with_path = false }]
end

type toplevel = Typedef of Typedef.t | Function of Func.t
[@@deriving show { with_path = false }]
