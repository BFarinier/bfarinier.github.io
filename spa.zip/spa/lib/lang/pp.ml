let pp_print_comma fmt () = Format.fprintf fmt ",@ "

let pp_print_semicolon fmt () = Format.fprintf fmt ";@\n"

let pp_brack pp fmt t = Format.fprintf fmt "@[<1>[%a]@]" pp t

let pp_paren pp fmt t = Format.fprintf fmt "@[<1>(%a)@]" pp t

(******************************************************************************)

let pp_tuple pp fmt list =
  Format.pp_print_list ~pp_sep:pp_print_comma pp fmt list


let pp_tuple_brack pp fmt list = pp_brack (pp_tuple pp) fmt list

let pp_tuple_paren pp fmt list = pp_paren (pp_tuple pp) fmt list

let pp_unop pp_exp fmt u exp = Format.fprintf fmt "@[%s%a@]" u pp_exp exp

let pp_bnop pp_exp fmt b exp1 exp2 =
  Format.fprintf fmt "@[%a@ %s@ %a@]" pp_exp exp1 b pp_exp exp2


let pp_rand fmt lo hi = Format.fprintf fmt "@[rand(%i, %i)@]" lo hi

let pp_call pp_exp fmt string list =
  Format.fprintf fmt "@[%s%a@]" string (pp_tuple_paren pp_exp) list


(******************************************************************************)

let pp_block pp_stm fmt blk =
  Format.(pp_print_list ~pp_sep:pp_force_newline pp_stm) fmt blk


let pp_assert pp_cnd fmt cnd =
  Format.fprintf fmt "@[assert @[<1>(%a)@];@]" pp_cnd cnd


let pp_assign pp_loc pp_exp fmt loc exp =
  Format.fprintf fmt "@[@[%a@] = @[%a@];@]" pp_loc loc pp_exp exp


let pp_if_then pp_cnd pp_blk fmt cnd blk =
  Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n}@\n" pp_cnd cnd pp_blk blk


let pp_if_then_else pp_cnd pp_blk fmt cnd blk1 blk2 =
  Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n@[<2>} else {@\n%a@]@\n}@\n"
    pp_cnd cnd pp_blk blk1 pp_blk blk2


let pp_while pp_cnd pp_blk fmt cnd blk =
  Format.fprintf fmt "@[<2>while (%a) {@\n%a@]@\n}@\n" pp_cnd cnd pp_blk blk


let pp_print pp_exp fmt exp = Format.fprintf fmt "@[print(%a);@]" pp_exp exp

let pp_do pp_exp fmt string list =
  Format.fprintf fmt "@[%s%a;@]" string (pp_tuple_paren pp_exp) list


let pp_return_none fmt () = Format.fprintf fmt "@[return;@]"

let pp_return_some pp_exp fmt exp =
  Format.fprintf fmt "@[return %a;@]" pp_exp exp


(******************************************************************************)

let pp_params pp fmt list = pp_tuple pp fmt list

let pp_locals pp fmt list =
  Format.pp_print_list ~pp_sep:pp_print_semicolon pp fmt list;
  if list <> [] then Format.fprintf fmt ";@\n@\n"


let pp_func pp_rettyp pp_typed_var pp_body fmt string rettyp params locals body
    =
  Format.fprintf fmt "@[<2>%a %s @[<1>(%a)@] {@\n%a%a@]@\n}@." pp_rettyp rettyp
    string (pp_params pp_typed_var) params (pp_locals pp_typed_var) locals
    pp_body body


let pp_env pp_func fmt list =
  Format.pp_print_list ~pp_sep:Format.pp_force_newline pp_func fmt list
