from argparse import ArgumentParser
from board import Disk, Board

if __name__ == '__main__':
    parser = ArgumentParser()
    args = parser.parse_args()
    Board(0, Disk.X, [])
