from __future__ import annotations

from enum import StrEnum
from typing import NamedTuple


class ParseError(Exception):
    pass


class Coordinate(NamedTuple):
    row: int
    col: int


class Disk(StrEnum):
    O = 'O'
    X = 'X'


Grid = list[list[Disk | None]]


class Board:

    def __init__(self: Board, size: int, player: Disk, grid: Grid):
        self.size: int = size
        self.player: Disk = player
        self.grid: Grid = grid

    @ staticmethod
    def create(size: int, player: Disk) -> Board:
        ...

    @ staticmethod
    def fromfile(file: str) -> Board:
        # open 'file' in read-only mode
        with open(file, 'r') as reader:
            # iterate over each line in 'file'
            for line in reader.readlines():
                ...

    def tofile(self: Board, file: str) -> None:
        # open 'file' for exclusive creation
        with open(file, 'x') as writter:
            # write current player in 'file'
            writter.write(self.player)
            ...

    def print(self: Board) -> None:
        ...
