open Core

type 'a located = {
  startpos : Lexing.position;
  endpos : Lexing.position;
  value : 'a;
}

let pp_located f fmt x = f fmt x.value

module Tree = struct
  type 'a t = Leaf of 'a | Node of 'a t list
  [@@deriving eq, ord, show { with_path = false }]

  let rec map f t =
    match t with
    | Leaf x -> Leaf (f x)
    | Node l -> Node (List.map (map f) l)


  let rec bind f t =
    match t with
    | Leaf x -> f x
    | Node l -> Node (List.map (bind f) l)


  let rec flatten t =
    match t with
    | Leaf x -> [ x ]
    | Node l -> List.flatten (List.map flatten l)


  let rec similar s t =
    match (s, t) with
    | Leaf _, Leaf _ | Node [], Node [] -> true
    | Node (s :: k), Node (t :: l) -> similar s t && similar (Node k) (Node l)
    | _, _ -> false


  let rec subset s t =
    match (s, t) with
    | Leaf _, _ | Node [], Node [] -> true
    | Node (s :: k), Node (t :: l) -> subset s t && subset (Node k) (Node l)
    | _, _ -> false


  let rec unify s t =
    match (s, t) with
    | Leaf x, t -> [ (x, t) ]
    | Node k, Node l -> List.flatten (List.map2 unify k l)
    | Node _, _ -> invalid_arg "unify"


  let unify s t = try Some (unify s t) with Invalid_argument _ -> None
end

module Expr = struct
  type unop = Neg [@@deriving show { with_path = false }]

  type bnop = Add | Sub | Mul [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Cst of int
    | Var of string
    | Unop of unop * t
    | Bnop of bnop * t * t
    | Call of string * t list
    | Tuple of t list
  [@@deriving show { with_path = false }]
end

module Cond = struct
  type cond = Eq | Nq | Le | Lt | Ge | Gt
  [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Atom of cond * Expr.t * Expr.t
    | Not of t
    | And of t * t
    | Or of t * t
  [@@deriving show { with_path = false }]
end

module Stmt = struct
  type typ = unit Tree.t [@@deriving show { with_path = false }]

  type loc = string Tree.t [@@deriving show { with_path = false }]

  type t = desc located [@@deriving show { with_path = false }]

  and desc =
    | Decl of typ * loc * Expr.t option
    | Assign of loc * Expr.t
    | Do of string * Expr.t list
    | Assert of Cond.t
    | Return of Expr.t option
    | If of Cond.t * block * block
    | While of Cond.t * block
  [@@deriving show { with_path = false }]

  and block = t list

  let pp_block fmt t =
    Format.pp_print_list ~pp_sep:Format.pp_force_newline pp fmt t
end

module Func = struct
  type t = desc located [@@deriving show { with_path = false }]

  and desc = {
    func_name : string;
    func_rettyp : Stmt.typ option;
    func_params : (Stmt.typ * string) list;
    func_body : Stmt.block;
  }
  [@@deriving show { with_path = false }]
end
