include Stdlib.Int

module Map = struct
  include Stdlib.Map.Make (Stdlib.Int)

  let hash h t = fold (fun int x hash -> Hashtbl.hash (int, h x, hash)) t 0
end

module Set = struct
  include Stdlib.Set.Make (Stdlib.Int)

  let hash t = fold (fun int hash -> Hashtbl.hash (int, hash)) t 0
end

module Hashtbl = Stdlib.Hashtbl.Make (Stdlib.Int)
