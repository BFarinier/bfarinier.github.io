include Stdlib.String

module Map = struct
  include Stdlib.Map.Make (Stdlib.String)

  let hash h t =
    fold
      (fun string x hash -> Hashtbl.hash (Stdlib.String.hash string, h x, hash))
      t 0
end

module Set = struct
  include Stdlib.Set.Make (Stdlib.String)

  let hash t =
    fold (fun string hash -> Hashtbl.hash (Stdlib.String.hash string, hash)) t 0
end

module Hashtbl = Stdlib.Hashtbl.Make (Stdlib.String)
