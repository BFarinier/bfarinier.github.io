include Stdlib.Result

exception Fail of string

type 'a t = ('a, string) Stdlib.Result.t

let error_exn exn = error (Printexc.to_string exn)

let error_format fmt = Format.kasprintf error fmt

let error_printf fmt = Printf.ksprintf error fmt

module List = struct
  let map (f : 'a -> 'b t) (list : 'a list) : 'b list t =
    try
      Ok
        (List.map
           (fun x ->
             match f x with
             | Ok x -> x
             | Error str -> raise (Fail str))
           list)
    with Fail str -> Error str


  let fold_left (f : 'a -> 'b -> 'a t) (acc : 'a) (list : 'b list) : 'a t =
    try
      Ok
        (List.fold_left
           (fun acc x ->
             match f acc x with
             | Ok acc -> acc
             | Error str -> raise (Fail str))
           acc list)
    with Fail str -> Error str


  let fold_left2 (f : 'a -> 'b -> 'c -> 'a t) (acc : 'a) (xs : 'b list)
      (ys : 'c list) : 'a t =
    try
      Ok
        (List.fold_left2
           (fun acc x y ->
             match f acc x y with
             | Ok acc -> acc
             | Error str -> raise (Fail str))
           acc xs ys)
    with Fail str -> Error str


  let fold_left_map (f : 'acc -> 'a -> ('acc * 'b) t) (acc : 'acc)
      (list : 'a list) : ('acc * 'b list) t =
    try
      Ok
        (List.fold_left_map
           (fun acc x ->
             match f acc x with
             | Ok (acc, x) -> (acc, x)
             | Error str -> raise (Fail str))
           acc list)
    with Fail str -> Error str


  let errors_concat errors = error (String.concat "\n" (List.rev errors))

  let map_collect (f : 'a -> 'b t) (list : 'a list) : 'b list t =
    let oks, errors =
      List.fold_left
        (fun (oks, errors) x ->
          match f x with
          | Ok ok -> (ok :: oks, errors)
          | Error error -> (oks, error :: errors))
        ([], []) list
    in
    if errors = [] then ok (List.rev oks) else errors_concat errors


  let fold_left_collect (f : 'a -> 'b -> 'a t) (acc : 'a) (list : 'b list) :
      'a t =
    let acc, errors =
      List.fold_left
        (fun (acc, errors) x ->
          match f acc x with
          | Ok acc -> (acc, errors)
          | Error error -> (acc, error :: errors))
        (acc, []) list
    in
    if errors = [] then ok acc else errors_concat errors
end

module Monad = struct
  let ( >>| ) (x : 'a t) (f : 'a -> 'b) : 'b t = map f x

  let ( >>= ) (x : 'a t) (f : 'a -> 'b t) : 'b t = bind x f

  let ( let+ ) (x : 'a t) (f : 'a -> 'b) : 'b t = map f x

  let ( let* ) (x : 'a t) (f : 'a -> 'b t) : 'b t = bind x f

  let ok t = ok t

  let error string = error string

  let error_exn exn = error_exn exn

  let error_format fmt = error_format fmt

  let error_printf fmt = error_printf fmt
end
