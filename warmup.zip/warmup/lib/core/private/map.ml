include Stdlib.Map

module type S = sig
  include Stdlib.Map.S

  val map2 : ('a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t

  val mapi2 : (key -> 'a -> 'b -> 'c) -> 'a t -> 'b t -> 'c t

  val exists2 : (key -> 'a -> 'b -> bool) -> 'a t -> 'b t -> bool

  val for_all2 : (key -> 'a -> 'b -> bool) -> 'a t -> 'b t -> bool
end

module Make (Ord : OrderedType) = struct
  include Stdlib.Map.Make (Ord)

  let combine s t =
    merge
      (fun _ a b ->
        match (a, b) with
        | Some a, Some b -> Some (a, b)
        | _ -> raise Not_found)
      s t


  let apply g f s t = g (fun (a, b) -> f a b) (combine s t) [@@inline]

  let applyi g f s t = g (fun key (a, b) -> f key a b) (combine s t) [@@inline]

  let map2 f s t = apply map f s t

  let mapi2 f s t = applyi mapi f s t

  let exists2 f s t = applyi exists f s t

  let for_all2 f s t = applyi for_all f s t
end
