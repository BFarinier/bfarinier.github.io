include Stdlib.List

let fold_left_map_filter f acc list =
  let acc, list = fold_left_map f acc list in
  (acc, filter_map Fun.id list)


let fold_left_map_concat f acc list =
  let acc, list = fold_left_map f acc list in
  (acc, concat list)
