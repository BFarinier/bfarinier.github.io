include Stdlib.Set

module type S = sig
  include Stdlib.Set.S

  val bind : (elt -> t) -> t -> t

  val bind2 : (elt -> elt -> t) -> t -> t -> t

  val map2 : (elt -> elt -> elt) -> t -> t -> t

  val filter2 : (elt -> elt -> bool) -> t -> t -> t * t

  val exists2 : (elt -> elt -> bool) -> t -> t -> bool

  val for_all2 : (elt -> elt -> bool) -> t -> t -> bool
end

module Make (Ord : OrderedType) = struct
  include Stdlib.Set.Make (Ord)

  let combine s t =
    fold (fun a acc -> fold (fun b acc -> (a, b) :: acc) t acc) s []


  let apply g f s t = g (fun (a, b) -> f a b) (combine s t) [@@inline]

  let bind f t = fold (fun a t -> union (f a) t) t empty

  let bind2 f s t = (List.fold_left union empty) (apply List.map f s t)

  let map2 f s t = of_list (apply List.map f s t)

  let filter2 f s t =
    let s, t = List.split (apply List.filter f s t) in
    (of_list s, of_list t)


  let exists2 f s t = apply List.exists f s t

  let for_all2 f s t = apply List.for_all f s t
end
