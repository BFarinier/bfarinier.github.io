include Stdlib
include Private
module Z = Zarith

type 'a result = 'a Result.t

let not_yet_implemented () = failwith "Not yet implemented."
