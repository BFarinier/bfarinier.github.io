open Core

module type EXPR = sig
  type t

  val compare : t -> t -> int

  val equal : t -> t -> bool

  val pp : Format.formatter -> t -> unit

  val debug : Format.formatter -> t -> unit
end

module Make (Expr : EXPR) = struct
  module Internal = struct
    module E = struct
      include Expr

      let pp fmt t = debug fmt t
    end

    type cond = Syntax.Cond.cond = Eq | Nq | Le | Lt | Ge | Gt
    [@@deriving eq, ord, show { with_path = false }]

    type t = Atom of cond * E.t * E.t | And of t * t | Or of t * t
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let string_of_cond c =
    match c with
    | Eq -> "=="
    | Nq -> "!="
    | Le -> "<="
    | Lt -> "<"
    | Ge -> ">="
    | Gt -> ">"


  let rec pp fmt (t : t) =
    match t with
    | Atom (a, e1, e2) ->
        Format.fprintf fmt "@[<1>%a@ %s@ %a@]" Expr.pp e1 (string_of_cond a)
          Expr.pp e2
    | And (c1, c2) ->
        Format.fprintf fmt "@[<1>%a@ &&@ %a@]" pp_paren c1 pp_paren c2
    | Or (c1, c2) ->
        Format.fprintf fmt "@[<1>%a@ ||@ %a@]" pp_paren c1 pp_paren c2


  and pp_paren fmt (t : t) = Format.fprintf fmt "@[<1>(%a)@]" pp t

  let atom a e1 e2 = Atom (a, e1, e2)

  let conj c1 c2 = And (c1, c2)

  let disj c1 c2 = Or (c1, c2)

  let rec not (t : t) =
    match t with
    | Atom (a, e1, e2) ->
        atom
          (match a with
          | Eq -> Nq
          | Nq -> Eq
          | Le -> Gt
          | Lt -> Ge
          | Ge -> Lt
          | Gt -> Le)
          e1 e2
    | And (c1, c2) -> disj (not c1) (not c2)
    | Or (c1, c2) -> conj (not c1) (not c2)
end
