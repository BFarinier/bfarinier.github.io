open Core

let pp_print_comma fmt () = Format.fprintf fmt ",@ "

let pp_print_semicolon fmt () = Format.fprintf fmt ";@\n"

module V = struct
  include Var

  let pp fmt t = debug fmt t
end

module Expr = struct
  module Internal = struct
    type unop = Syntax.Expr.unop = Neg
    [@@deriving eq, ord, show { with_path = false }]

    type bnop = Syntax.Expr.bnop = Add | Sub | Mul
    [@@deriving eq, ord, show { with_path = false }]

    type t =
      | Cst of int
      | Var of V.t
      | Unop of unop * t
      | Bnop of bnop * t * t
      | Rand of int * int
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let string_of_unop u =
    match u with
    | Neg -> "-"


  let string_of_bnop b =
    match b with
    | Add -> "+"
    | Sub -> "-"
    | Mul -> "*"


  let rec pp fmt (t : t) =
    match t with
    | Cst i -> Format.pp_print_int fmt i
    | Var v -> Var.pp fmt v
    | Unop (u, ex) ->
        Format.fprintf fmt "@[<1>%s%a@]" (string_of_unop u) pp_paren ex
    | Bnop (b, ex1, ex2) ->
        Format.fprintf fmt "@[<1>%a@ %s@ %a@]" pp_paren ex1 (string_of_bnop b)
          pp_paren ex2
    | Rand (lo, hi) -> Format.fprintf fmt "@[rand(%i, %i)@]" lo hi


  and pp_paren fmt (t : t) =
    match t with
    | Cst i when i < 0 -> Format.fprintf fmt "@[<1>(%a)@]" pp t
    | Cst _ | Var _ | Rand _ -> pp fmt t
    | Unop _ | Bnop _ -> Format.fprintf fmt "@[<1>(%a)@]" pp t


  let cst i = Cst i

  let var v = Var v

  let unop u t = Unop (u, t)

  let bnop b t1 t2 = Bnop (b, t1, t2)

  let rand lo hi = Rand (lo, hi)
end

module E = Expr.Internal
module Cond = Cond.Make (Expr)

module C = struct
  include Cond

  let pp fmt t = debug fmt t
end

module Stmt = struct
  module Internal = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of V.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
      | Call of V.t list * string * E.t list
      | Return of E.t list
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Format.fprintf fmt "@[assert @[<1>(%a)@];@]" Cond.pp cd
    | Assign (v, ex) ->
        Format.fprintf fmt "@[@[%a@] = @[%a@];@]" Var.pp v Expr.pp ex
    | If (cd, bl, []) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n}@\n" Cond.pp cd
          Format.(pp_print_list ~pp_sep:pp_force_newline pp)
          bl
    | If (cd, bl1, bl2) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n@[<2>} else {@\n%a@]@\n}@\n"
          Cond.pp cd pp_block bl1 pp_block bl2
    | While (cd, bl) ->
        Format.fprintf fmt "@[<2>while (%a) {@\n%a@]@\n}@\n" Cond.pp cd pp_block
          bl
    | Print ex -> Format.fprintf fmt "@[print(%a);@]" Expr.pp ex
    | Call ([], s, exs) -> Format.fprintf fmt "@[%s@[<1>(%a)@];@]" s pp_args exs
    | Call (ls, s, exs) ->
        Format.fprintf fmt "@[@[%a@] = %s@[<1>(%a)@];@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma Var.pp)
          ls s pp_args exs
    | Return ls ->
        Format.fprintf fmt "@[return %a;@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma Expr.pp_paren)
          ls


  and pp_block fmt lst =
    Format.(pp_print_list ~pp_sep:pp_force_newline pp) fmt lst


  and pp_args fmt lst =
    Format.(pp_print_list ~pp_sep:pp_print_comma Expr.pp) fmt lst


  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

module S = Stmt.Internal

module Func = struct
  module Internal = struct
    type t = {
      func_pos : Position.t; [@opaque]
      func_name : string;
      func_rettyp : int;
      func_params : V.t list;
      func_locals : V.t list;
      func_body : S.block;
    }
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let pp_rettyp fmt t =
    if t <= 0 then Format.pp_print_string fmt "void"
    else if t = 1 then Format.pp_print_string fmt "int"
    else
      Format.fprintf fmt "@[[ %a ]@]"
        (Format.pp_print_list ~pp_sep:pp_print_comma Format.pp_print_string)
        (List.init t (fun _ -> "int"))


  let pp_params fmt lst =
    Format.(
      pp_print_list ~pp_sep:pp_print_comma (fun fmt v ->
          Format.fprintf fmt "int %a" Var.pp v))
      fmt lst


  let pp_locals fmt lst =
    Format.(
      pp_print_list ~pp_sep:pp_print_semicolon (fun fmt v ->
          Format.fprintf fmt "int %a" Var.pp v))
      fmt lst;
    if lst <> [] then Format.fprintf fmt ";@\n@\n"


  let pp fmt { func_name; func_rettyp; func_params; func_locals; func_body; _ }
      =
    Format.fprintf fmt "@[<2>%a %s @[<1>(%a)@] {@\n%a%a@]@\n}@\n" pp_rettyp
      func_rettyp func_name pp_params func_params pp_locals func_locals
      Stmt.pp_block func_body
end

module Env = struct
  type t = (string * Func.t) list

  let make list = List.map (fun func -> (func.Func.func_name, func)) list

  let find string t = List.assoc string t

  let functions t = List.map snd t
end

type program = { environment : Env.t; entrypoint : string }

let pp fmt { environment; _ } =
  Format.pp_print_list ~pp_sep:Format.pp_force_newline Func.pp fmt
    (Env.functions environment)


(******************************************************************************)

let ensure_single l =
  match l with
  | [ x ] -> x
  | _ -> assert false


let flattened_typopt opt =
  match opt with
  | None -> 0
  | Some ty -> List.length (Syntax.Tree.flatten ty)


let rec flattened_var (var, ty) =
  match ty with
  | Syntax.Tree.Leaf _ -> [ var ]
  | Syntax.Tree.Node l ->
      List.flatten
        (List.mapi
           (fun i ty -> flattened_var (Var.sub var (string_of_int i), ty))
           l)


let flattened_loc (loc : Typed.Loc.t) = List.map fst (Syntax.Tree.flatten loc)

let rec flattened_expr fresh sigs pos ((ctx, _) as ctx_lst)
    (expr : Typed.Expr.t) =
  match expr with
  | Typed.Expr.Cst int -> (ctx_lst, [ Expr.cst int ])
  | Typed.Expr.Var var -> (ctx_lst, List.map Expr.var (Var.Map.find var ctx))
  | Typed.Expr.Unop (u, exp) ->
      let ctx_lst, exp = flattened_expr fresh sigs pos ctx_lst exp in
      let exp = ensure_single exp in
      (ctx_lst, [ Expr.unop u exp ])
  | Typed.Expr.Bnop (b, exp1, exp2) ->
      let ctx_lst, exp1 = flattened_expr fresh sigs pos ctx_lst exp1 in
      let ctx_lst, exp2 = flattened_expr fresh sigs pos ctx_lst exp2 in
      let exp1 = ensure_single exp1 in
      let exp2 = ensure_single exp2 in
      (ctx_lst, [ Expr.bnop b exp1 exp2 ])
  | Typed.Expr.Rand (lo, hi) -> (ctx_lst, [ Expr.rand lo hi ])
  | Typed.Expr.Call (string, exps) ->
      let rettyp = String.Map.find string sigs in
      let vars = List.init rettyp (fun _ -> fresh ()) in
      let (ctx, lst), exps =
        List.fold_left_map (flattened_expr fresh sigs pos) ctx_lst exps
      in
      let ctx =
        List.fold_left (fun ctx var -> Var.Map.add var [ var ] ctx) ctx vars
      in
      ( (ctx, Stmt.make pos (Call (vars, string, List.flatten exps)) :: lst),
        List.map Expr.var vars )
  | Typed.Expr.Tuple exps ->
      let ctx_lst, exps =
        List.fold_left_map (flattened_expr fresh sigs pos) ctx_lst exps
      in
      (ctx_lst, List.flatten exps)


let rec flattened_cond fresh sigs pos ctx_lst (cond : Typed.Cond.t) =
  match cond with
  | Typed.Cond.Atom (c, exp1, exp2) ->
      let ctx_lst, exp1 = flattened_expr fresh sigs pos ctx_lst exp1 in
      let ctx_lst, exp2 = flattened_expr fresh sigs pos ctx_lst exp2 in
      let exp1 = ensure_single exp1 in
      let exp2 = ensure_single exp2 in
      (ctx_lst, Cond.atom c exp1 exp2)
  | Typed.Cond.And (cnd1, cnd2) ->
      let ctx_lst, cnd1 = flattened_cond fresh sigs pos ctx_lst cnd1 in
      let ctx_lst, cnd2 = flattened_cond fresh sigs pos ctx_lst cnd2 in
      (ctx_lst, Cond.conj cnd1 cnd2)
  | Typed.Cond.Or (cnd1, cnd2) ->
      let ctx_lst, cnd1 = flattened_cond fresh sigs pos ctx_lst cnd1 in
      let ctx_lst, cnd2 = flattened_cond fresh sigs pos ctx_lst cnd2 in
      (ctx_lst, Cond.disj cnd1 cnd2)


let rec flattened_stmt fresh sigs ((ctx, lst) as ctx_lst)
    ({ stmt_pos; stmt_desc } : Typed.Stmt.t) =
  match stmt_desc with
  | Typed.Stmt.Assert cnd ->
      let (ctx, lst), cnd = flattened_cond fresh sigs stmt_pos ctx_lst cnd in
      (ctx, Stmt.(make stmt_pos (Assert cnd)) :: lst)
  | Typed.Stmt.Assign (loc, exp) -> (
      let var =
        List.flatten
          (List.map (fun v -> Var.Map.find v ctx) (flattened_loc loc))
      in
      match exp with
      | Call (string, exps) ->
          let (ctx, lst), exps =
            List.fold_left_map (flattened_expr fresh sigs stmt_pos) ctx_lst exps
          in
          ( ctx,
            Stmt.(make stmt_pos (Call (var, string, List.flatten exps))) :: lst
          )
      | exp ->
          let (ctx, lst), exp =
            flattened_expr fresh sigs stmt_pos ctx_lst exp
          in
          ( ctx,
            List.rev_append
              (List.map2
                 (fun var exp -> Stmt.(make stmt_pos (Assign (var, exp))))
                 var exp)
              lst ))
  | Typed.Stmt.If (cnd, blk1, blk2) ->
      let (ctx, lst), cnd = flattened_cond fresh sigs stmt_pos ctx_lst cnd in
      let ctx, blk1 = flattened_block fresh sigs ctx blk1 in
      let ctx, blk2 = flattened_block fresh sigs ctx blk2 in
      (ctx, Stmt.(make stmt_pos (If (cnd, blk1, blk2))) :: lst)
  | Typed.Stmt.While (cnd, blk) ->
      let (ctx, l), cnd = flattened_cond fresh sigs stmt_pos (ctx, []) cnd in
      let ctx, blk = flattened_block fresh sigs ctx blk in
      (ctx, Stmt.(make stmt_pos (While (cnd, blk @ List.rev l))) :: (l @ lst))
  | Typed.Stmt.Print exp ->
      let (ctx, lst), exp = flattened_expr fresh sigs stmt_pos ctx_lst exp in
      let exp = ensure_single exp in
      (ctx, Stmt.(make stmt_pos (Print exp)) :: lst)
  | Typed.Stmt.Do (string, exps) ->
      let (ctx, lst), exps =
        List.fold_left_map (flattened_expr fresh sigs stmt_pos) ctx_lst exps
      in
      (ctx, Stmt.make stmt_pos (Call ([], string, List.flatten exps)) :: lst)
  | Typed.Stmt.Return None -> (ctx, Stmt.(make stmt_pos (Return [])) :: lst)
  | Typed.Stmt.Return (Some exp) ->
      let (ctx, lst), exp = flattened_expr fresh sigs stmt_pos ctx_lst exp in
      (ctx, Stmt.(make stmt_pos (Return exp)) :: lst)


and flattened_block fresh sigs ctx blk =
  let ctx, blk =
    List.fold_left
      (fun ctx_lst stmt -> flattened_stmt fresh sigs ctx_lst stmt)
      (ctx, []) blk
  in
  (ctx, List.rev blk)


let flattened_func sigs (func : Typed.Func.t) =
  let func_pos = func.Typed.Func.func_pos in
  let func_name = func.Typed.Func.func_name in
  let func_rettyp = flattened_typopt func.Typed.Func.func_rettyp in
  let ctx, func_params =
    List.fold_left_map
      (fun ctx ((var, _) as var_ty) ->
        let vars = flattened_var var_ty in
        (Var.Map.add var vars ctx, vars))
      Var.Map.empty func.Typed.Func.func_params
  in
  let func_params = List.flatten func_params in
  let ctx =
    List.fold_left
      (fun ctx ((var, _) as var_ty) ->
        let vars = flattened_var var_ty in
        Var.Map.add var vars ctx)
      ctx func.Typed.Func.func_locals
  in
  let ctx, func_body =
    flattened_block
      (Var.fresh ~func:func_name)
      sigs ctx func.Typed.Func.func_body
  in
  let func_locals =
    Var.Set.elements
      (List.fold_left
         (fun ctx var -> Var.Set.remove var ctx)
         (Var.Set.of_list (List.flatten (List.map snd (Var.Map.bindings ctx))))
         func_params)
  in
  ( String.Map.add func_name func_rettyp sigs,
    Func.
      { func_pos; func_name; func_rettyp; func_params; func_locals; func_body }
  )


let flattened_funcs list =
  let _, list = List.fold_left_map flattened_func String.Map.empty list in
  list


let flattened_program ({ environment; entrypoint } : Typed.program) =
  let environment =
    Env.make (flattened_funcs (Typed.Env.functions environment))
  in
  { environment; entrypoint }


let parse_program file = flattened_program (Typed.parse_program file)
