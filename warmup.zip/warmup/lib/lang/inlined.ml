module V = struct
  include Var

  let pp fmt t = debug fmt t
end

module Expr = struct
  include Flattened.Expr

  let rec pp_qualified fmt (t : t) =
    match t with
    | Cst i -> Format.pp_print_int fmt i
    | Var v -> Var.pp_qualified fmt v
    | Unop (u, ex) ->
        Format.fprintf fmt "@[<1>%s%a@]" (string_of_unop u) pp_paren_qualified
          ex
    | Bnop (b, ex1, ex2) ->
        Format.fprintf fmt "@[<1>%a@ %s@ %a@]" pp_paren_qualified ex1
          (string_of_bnop b) pp_paren_qualified ex2
    | Rand (lo, hi) -> Format.fprintf fmt "@[rand(%i, %i)@]" lo hi


  and pp_paren_qualified fmt (t : t) =
    match t with
    | Cst i when i < 0 -> Format.fprintf fmt "@[<1>(%a)@]" pp_qualified t
    | Cst _ | Var _ | Rand _ -> pp_qualified fmt t
    | Unop _ | Bnop _ -> Format.fprintf fmt "@[<1>(%a)@]" pp_qualified t
end

module E = struct
  include Expr

  let pp fmt t = debug fmt t
end

module Cond = struct
  include Flattened.Cond

  let rec pp_qualified fmt (t : t) =
    match t with
    | Atom (a, e1, e2) ->
        Format.fprintf fmt "@[<1>%a@ %s@ %a@]" Expr.pp_qualified e1
          (string_of_cond a) Expr.pp_qualified e2
    | And (c1, c2) ->
        Format.fprintf fmt "@[<1>%a@ &&@ %a@]" pp_paren_qualified c1
          pp_paren_qualified c2
    | Or (c1, c2) ->
        Format.fprintf fmt "@[<1>%a@ ||@ %a@]" pp_paren_qualified c1
          pp_paren_qualified c2


  and pp_paren_qualified fmt (t : t) =
    Format.fprintf fmt "@[<1>(%a)@]" pp_qualified t
end

module C = struct
  include Cond

  let pp fmt t = debug fmt t
end

module Stmt = struct
  module Internal = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of V.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd ->
        Format.fprintf fmt "@[assert @[<1>(%a)@];@]" Cond.pp_qualified cd
    | Assign (v, ex) ->
        Format.fprintf fmt "@[@[%a@] = @[%a@];@]" Var.pp_qualified v
          Expr.pp_qualified ex
    | If (cd, bl, []) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n}@\n" Cond.pp_qualified cd
          Format.(pp_print_list ~pp_sep:pp_force_newline pp)
          bl
    | If (cd, bl1, bl2) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n@[<2>} else {@\n%a@]@\n}@\n"
          Cond.pp_qualified cd pp_block bl1 pp_block bl2
    | While (cd, bl) ->
        Format.fprintf fmt "@[<2>while (%a) {@\n%a@]@\n}@\n" Cond.pp_qualified
          cd pp_block bl
    | Print ex -> Format.fprintf fmt "@[print(%a);@]" Expr.pp_qualified ex


  and pp_block fmt lst =
    Format.(pp_print_list ~pp_sep:pp_force_newline pp) fmt lst


  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

type program = { vars : Var.t list; body : Stmt.block }

let pp fmt { body; _ } = Stmt.pp_block fmt body

(******************************************************************************)

let rec inlined_stmt env rets ((set, lst) as set_lst)
    ({ stmt_pos; stmt_desc } : Flattened.Stmt.t) =
  match stmt_desc with
  | Flattened.Stmt.Assert cnd -> (set, Stmt.(make stmt_pos (Assert cnd)) :: lst)
  | Flattened.Stmt.Assign (var, exp) ->
      (set, Stmt.(make stmt_pos (Assign (var, exp))) :: lst)
  | Flattened.Stmt.If (cnd, blk1, blk2) ->
      let set, blk1 = inlined_block env rets (set, []) blk1 in
      let set, blk2 = inlined_block env rets (set, []) blk2 in
      (set, Stmt.(make stmt_pos (If (cnd, blk1, blk2))) :: lst)
  | Flattened.Stmt.While (cnd, blk) ->
      let set, blk = inlined_block env rets (set, []) blk in
      (set, Stmt.(make stmt_pos (While (cnd, blk))) :: lst)
  | Flattened.Stmt.Print exp -> (set, Stmt.(make stmt_pos (Print exp)) :: lst)
  | Flattened.Stmt.Call (vars, string, exps) ->
      let func = Flattened.Env.find string env in
      let set, l = inlined_func env vars func exps set in
      (set, List.rev_append l lst)
  | Flattened.Stmt.Return exps ->
      List.fold_left2
        (fun (set, lst) var exp ->
          (set, Stmt.(make stmt_pos (Assign (var, exp))) :: lst))
        set_lst rets exps


and inlined_block env rets set_lst blk =
  let set, lst = List.fold_left (inlined_stmt env rets) set_lst blk in
  (set, List.rev lst)


and inlined_func env vars func exps set =
  let set =
    List.fold_left
      (fun set var -> Var.Set.add var set)
      set func.Flattened.Func.func_locals
  in
  let lst =
    List.fold_left2
      (fun lst var exp ->
        Stmt.(make func.Flattened.Func.func_pos (Assign (var, exp))) :: lst)
      [] func.Flattened.Func.func_params exps
  in
  let lst =
    List.fold_left
      (fun lst var ->
        Stmt.(make func.Flattened.Func.func_pos (Assign (var, Expr.cst 0)))
        :: lst)
      lst func.Flattened.Func.func_locals
  in
  inlined_block env vars (set, lst) func.Flattened.Func.func_body


let inlined_program ({ environment; entrypoint } : Flattened.program) =
  let func = Flattened.Env.find entrypoint environment in
  let vars, body = inlined_func environment [] func [] Var.Set.empty in
  { vars = Var.Set.elements vars; body }


let parse_program file = inlined_program (Flattened.parse_program file)
