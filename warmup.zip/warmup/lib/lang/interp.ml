open Core
open Inlined

exception AssertionFailure of string

(** Raise an assertion failure for the given source position. *)
let assertion_failure pos =
  raise (AssertionFailure (Format.asprintf "%a" Position.pp pos))


(** Read an integer within the given bounds. Ask the user for a value. On error,
    pick a pseudorandom value in the same bounds. Return the selected integer.
*)
let not_so_random lo hi =
  assert (lo <= hi);
  Printf.printf "Enter a value between %i and %i (incl.): " lo hi;
  let i = try int_of_string (read_line ()) with _ -> max_int in
  if i < lo || i > hi then (
    let i = Random.int_in_range ~min:lo ~max:hi in
    Printf.printf "Invalid value, continuing with %i.\n%!" i;
    i)
  else i


(** Print the given arbitrary-precision integer followed by a newline. *)
let print i = print_endline (Z.to_string i)

(******************************************************************************)
(**************************** BEGIN TODO **************************************)

type state = Z.t Var.Map.t

let rec eval_expr (stt : state) (expr : Expr.t) : Z.t =
  match expr with
  | Expr.Cst _ -> not_yet_implemented ()
  | Expr.Var _ -> not_yet_implemented ()
  | Expr.Unop _ -> not_yet_implemented ()
  | Expr.Bnop _ -> not_yet_implemented ()
  | Expr.Rand (lo, hi) -> Z.of_int (not_so_random lo hi)


let rec eval_cond (stt : state) (cond : Cond.t) : bool =
  match cond with
  | Inlined.Cond.Atom _ -> not_yet_implemented ()
  | Inlined.Cond.And _ -> not_yet_implemented ()
  | Inlined.Cond.Or _ -> not_yet_implemented ()


let rec eval_stmt (stt : state) (stmt : Stmt.t) : state =
  match stmt.stmt_desc with
  | Inlined.Stmt.Assert _ ->
      if not_yet_implemented () then not_yet_implemented ()
      else assertion_failure stmt.stmt_pos
  | Inlined.Stmt.Assign _ -> not_yet_implemented ()
  | Inlined.Stmt.If _ -> not_yet_implemented ()
  | Inlined.Stmt.While _ -> not_yet_implemented ()
  | Inlined.Stmt.Print _ ->
      print (not_yet_implemented ());
      not_yet_implemented ()


and eval_block (stt : state) (block : Stmt.block) : state =
  not_yet_implemented ()


(**************************** END TODO ****************************************)
(******************************************************************************)

let eval (program : program) : unit =
  (* Evaluate the program body with an empty initial state
     and discard the returned state. *)
  ignore (eval_block Var.Map.empty program.body)
