open Core

module Var = struct
  type t = { var_func : string; var_name : string list }
  [@@deriving eq, ord, show { with_path = false }]
end

include Var

let debug fmt t = pp fmt t

let named ?(func = "") (name : string) =
  { var_func = func; var_name = [ name ] }


let fresh ?(func = "") =
  let cnt = ref (-1) in
  fun () ->
    incr cnt;
    { var_func = func; var_name = [ string_of_int !cnt; "@" ] }


let name { var_name; _ } = String.concat "." (List.rev var_name)

let sub var string = { var with var_name = string :: var.var_name }

let pp fmt var = Format.pp_print_string fmt (name var)

let pp_qualified fmt ({ var_func; _ } as t) =
  Format.fprintf fmt "%s.%a" var_func pp t


let serialize t = Format.asprintf "%a" pp_qualified t

module Map = Map.Make (Var)
module Set = Set.Make (Var)
