open Core
open Result.Monad

let pp_print_comma fmt () = Format.fprintf fmt ",@ "

let pp_print_semicolon fmt () = Format.fprintf fmt ";@\n"

let error_pos pos fmt =
  Format.kasprintf
    (fun str -> error_format "%a: %s." Position.pp_with_offset pos str)
    fmt


let type_error pos pp_a a pp_b b pp_c c =
  error_pos pos "%a has type %a but was expected of type %a" pp_a a pp_b b pp_c
    c


let invalid_number pos ident =
  error_pos pos "invalid number of arguments for function %s" ident


let unknown pos kind name = error_pos pos "unknown %s %s" kind name

let unknown_function pos name = unknown pos "function" name

let unknown_variable pos name = unknown pos "variable" name

(******************************************************************************)

module V = struct
  include Var

  let pp fmt t = debug fmt t
end

module Type = struct
  module Internal = struct
    type t = unit Syntax.Tree.t [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt (t : t) =
    match t with
    | Syntax.Tree.Leaf _ -> Format.pp_print_string fmt "int"
    | Syntax.Tree.Node l ->
        Format.fprintf fmt "@[<1>[%a]@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma pp)
          l


  let pp_opt fmt opt =
    match opt with
    | None -> Format.pp_print_string fmt "void"
    | Some t -> pp fmt t


  let int = Syntax.Tree.Leaf ()

  let tuple l = Syntax.Tree.Node l

  let is_int t = equal t int
end

module T = Type.Internal

module Loc = struct
  module Internal = struct
    type t = (V.t * T.t) Syntax.Tree.t
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let rec pp fmt (t : t) =
    match t with
    | Syntax.Tree.Leaf (v, _) -> Format.pp_print_string fmt (Var.name v)
    | Syntax.Tree.Node l ->
        Format.fprintf fmt "@[<1>(%a)@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma pp)
          l


  let var v t = Syntax.Tree.Leaf (v, t)

  let tuple l = Syntax.Tree.Node l
end

module L = Loc.Internal

module Expr = struct
  module Internal = struct
    type unop = Syntax.Expr.unop = Neg
    [@@deriving eq, ord, show { with_path = false }]

    type bnop = Syntax.Expr.bnop = Add | Sub | Mul
    [@@deriving eq, ord, show { with_path = false }]

    type t =
      | Cst of int
      | Var of V.t
      | Unop of unop * t
      | Bnop of bnop * t * t
      | Rand of int * int
      | Call of string * t list
      | Tuple of t list
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let string_of_unop u =
    match u with
    | Neg -> "-"


  let string_of_bnop b =
    match b with
    | Add -> "+"
    | Sub -> "-"
    | Mul -> "*"


  let rec pp fmt (t : t) =
    match t with
    | Cst i -> Format.pp_print_int fmt i
    | Var v -> Var.pp fmt v
    | Unop (u, ex) ->
        Format.fprintf fmt "@[<1>%s%a@]" (string_of_unop u) pp_paren ex
    | Bnop (b, ex1, ex2) ->
        Format.fprintf fmt "@[<1>%a@ %s@ %a@]" pp_paren ex1 (string_of_bnop b)
          pp_paren ex2
    | Rand (lo, hi) -> Format.fprintf fmt "@[rand(%i, %i)@]" lo hi
    | Call (s, exs) -> Format.fprintf fmt "@[%s@[<1>(%a)@]@]" s pp_args exs
    | Tuple l ->
        Format.fprintf fmt "@[<1>(%a)@]"
          (Format.pp_print_list ~pp_sep:pp_print_comma pp)
          l


  and pp_args fmt lst = Format.(pp_print_list ~pp_sep:pp_print_comma pp) fmt lst

  and pp_paren fmt (t : t) =
    match t with
    | Cst i when i < 0 -> Format.fprintf fmt "@[<1>(%a)@]" pp t
    | Cst _ | Var _ | Rand _ | Call _ | Tuple _ -> pp fmt t
    | Unop _ | Bnop _ -> Format.fprintf fmt "@[<1>(%a)@]" pp t


  let cst i = Cst i

  let var v = Var v

  let unop u t = Unop (u, t)

  let bnop b t1 t2 = Bnop (b, t1, t2)

  let rand lo hi = Rand (lo, hi)

  let call s l = Call (s, l)

  let tuple l = Tuple l
end

module E = Expr.Internal
module Cond = Cond.Make (Expr)

module C = struct
  include Cond

  let pp fmt t = debug fmt t
end

module Stmt = struct
  module Internal = struct
    type t = { stmt_pos : Position.t; [@opaque] stmt_desc : desc }
    [@@deriving eq, ord, show { with_path = false }]

    and desc =
      | Assert of C.t
      | Assign of L.t * E.t
      | If of C.t * block * block
      | While of C.t * block
      | Print of E.t
      | Do of string * E.t list
      | Return of E.t option
    [@@deriving eq, ord, show { with_path = false }]

    and block = t list [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  type builtin = BuiltInRand | BuiltInPrint

  let string_of_builtin (b : builtin) =
    match b with
    | BuiltInRand -> "rand"
    | BuiltInPrint -> "print"


  let builtin_of_string s =
    match s with
    | "rand" -> Some BuiltInRand
    | "print" -> Some BuiltInPrint
    | _ -> None


  let rec pp fmt ({ stmt_desc; _ } : t) =
    match stmt_desc with
    | Assert cd -> Format.fprintf fmt "@[assert @[<1>(%a)@];@]" Cond.pp cd
    | Assign (lo, ex) ->
        Format.fprintf fmt "@[@[%a@] = @[%a@];@]" Loc.pp lo Expr.pp ex
    | If (cd, bl, []) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n}@\n" Cond.pp cd
          Format.(pp_print_list ~pp_sep:pp_force_newline pp)
          bl
    | If (cd, bl1, bl2) ->
        Format.fprintf fmt "@[<2>if (%a) {@\n%a@]@\n@[<2>} else {@\n%a@]@\n}@\n"
          Cond.pp cd pp_block bl1 pp_block bl2
    | While (cd, bl) ->
        Format.fprintf fmt "@[<2>while (%a) {@\n%a@]@\n}@\n" Cond.pp cd pp_block
          bl
    | Print ex -> Format.fprintf fmt "@[print(%a);@]" Expr.pp ex
    | Do (s, exs) -> Format.fprintf fmt "@[%s(%a);@]" s pp_args exs
    | Return None -> Format.fprintf fmt "@[return;@]"
    | Return (Some ex) -> Format.fprintf fmt "@[return %a;@]" Expr.pp ex


  and pp_block fmt lst =
    Format.(pp_print_list ~pp_sep:pp_force_newline pp) fmt lst


  and pp_args fmt lst =
    Format.(pp_print_list ~pp_sep:pp_print_comma Expr.pp) fmt lst


  let make stmt_pos stmt_desc = { stmt_pos; stmt_desc }
end

module S = Stmt.Internal

module Func = struct
  module Internal = struct
    type t = {
      func_pos : Position.t; [@opaque]
      func_name : string;
      func_rettyp : T.t option;
      func_params : (V.t * T.t) list;
      func_locals : (V.t * T.t) list;
      func_body : S.block;
    }
    [@@deriving eq, ord, show { with_path = false }]
  end

  include Internal

  let debug fmt t = pp fmt t

  let pp_params fmt lst =
    Format.(
      pp_print_list ~pp_sep:pp_print_comma (fun fmt (v, ty) ->
          Format.fprintf fmt "%a %a" Type.pp ty Var.pp v))
      fmt lst


  let pp_locals fmt lst =
    Format.(
      pp_print_list ~pp_sep:pp_print_semicolon (fun fmt (v, ty) ->
          Format.fprintf fmt "%a %a" Type.pp ty Var.pp v))
      fmt lst;
    if lst <> [] then Format.fprintf fmt ";@\n@\n"


  let pp fmt { func_name; func_rettyp; func_params; func_locals; func_body; _ }
      =
    Format.fprintf fmt "@[<2>%a %s @[<1>(%a)@] {@\n%a%a@]@\n}@." Type.pp_opt
      func_rettyp func_name pp_params func_params pp_locals func_locals
      Stmt.pp_block func_body
end

module Env = struct
  type t = (string * Func.t) list

  let make list = List.map (fun func -> (func.Func.func_name, func)) list

  let find string t = List.assoc string t

  let functions t = List.map snd t
end

type program = { environment : Env.t; entrypoint : string }

let pp fmt { environment; _ } =
  Format.pp_print_list ~pp_sep:Format.pp_force_newline Func.pp fmt
    (Env.functions environment)


(******************************************************************************)

let find_signature sigs pos string =
  match String.Map.find_opt string sigs with
  | Some (rettyp, l) -> ok (Either.Left string, rettyp, l)
  | None -> (
      match Stmt.builtin_of_string string with
      | Some (BuiltInRand as bi) ->
          ok (Either.Right bi, Some Type.int, [ Type.int; Type.int ])
      | Some (BuiltInPrint as bi) -> ok (Either.Right bi, None, [ Type.int ])
      | None -> unknown_function pos string)


let ensure_int pos exp ty =
  if Type.is_int ty then ok ()
  else type_error pos Expr.pp exp Type.pp ty Type.pp Type.int


let rec typed_expr sigs ctx ({ value; startpos; _ } : Syntax.Expr.t) =
  match value with
  | Syntax.Expr.Cst int -> ok (Expr.cst int, Type.int)
  | Syntax.Expr.Var string -> (
      match String.Map.find_opt string ctx with
      | Some (v, ty) -> ok (Expr.var v, ty)
      | None -> unknown_variable startpos string)
  | Syntax.Expr.Unop (u, exp) ->
      let* exp, typ = typed_expr sigs ctx exp in
      let* () = ensure_int startpos exp typ in
      ok (Expr.unop u exp, typ)
  | Syntax.Expr.Bnop (b, exp1, exp2) ->
      let* exp1, typ1 = typed_expr sigs ctx exp1 in
      let* exp2, typ2 = typed_expr sigs ctx exp2 in
      let* () = ensure_int startpos exp1 typ1 in
      let* () = ensure_int startpos exp2 typ2 in
      ok (Expr.bnop b exp1 exp2, typ1)
  | Syntax.Expr.Call (string, exps) -> (
      let* either = typed_call sigs ctx startpos string exps in
      match either with
      | Either.Right _ -> error_pos startpos "%s has type void" string
      | Either.Left (exp, rettyp) -> ok (exp, rettyp))
  | Syntax.Expr.Tuple exps ->
      let* exps, typs = typed_exprs sigs ctx exps in
      ok (Expr.tuple exps, Type.tuple typs)


and typed_exprs sigs ctx exps =
  let* exps, typs =
    Result.List.fold_left
      (fun (es, ts) e ->
        let* e, t = typed_expr sigs ctx e in
        ok (e :: es, t :: ts))
      ([], []) exps
  in
  ok (List.rev exps, List.rev typs)


and typed_call sigs ctx pos string exps =
  let* ident, rettyp, arity = find_signature sigs pos string in
  let* exps, typs = typed_exprs sigs ctx exps in
  match ident with
  | Either.Left string ->
      if List.equal Type.equal typs arity then
        match rettyp with
        | None -> ok (Either.Right (Stmt.Do (string, exps)))
        | Some rettyp -> ok (Either.Left (Expr.call string exps, rettyp))
      else invalid_number pos string
  | Either.Right bi -> (
      match (bi, exps) with
      | Stmt.BuiltInRand, [ lo; hi ] -> (
          match (lo, hi) with
          | Cst lo, Cst hi when lo <= hi ->
              ok (Either.Left (Expr.Rand (lo, hi), Type.int))
          | _ -> error_pos pos "invalid bounds for function rand")
      | Stmt.BuiltInPrint, [ exp ] -> ok (Either.Right (Stmt.Print exp))
      | _ -> invalid_number pos (Stmt.string_of_builtin bi))


let rec typed_cond sigs ctx ({ value; startpos; _ } : Syntax.Cond.t) =
  match value with
  | Syntax.Cond.Atom (a, exp1, exp2) ->
      let* exp1, typ1 = typed_expr sigs ctx exp1 in
      let* exp2, typ2 = typed_expr sigs ctx exp2 in
      let* () = ensure_int startpos exp1 typ1 in
      let* () = ensure_int startpos exp2 typ2 in
      ok (Cond.atom a exp1 exp2)
  | Syntax.Cond.Not cnd ->
      let* cnd = typed_cond sigs ctx cnd in
      ok (Cond.not cnd)
  | Syntax.Cond.And (cnd1, cnd2) ->
      let* cnd1 = typed_cond sigs ctx cnd1 in
      let* cnd2 = typed_cond sigs ctx cnd2 in
      ok (Cond.conj cnd1 cnd2)
  | Syntax.Cond.Or (cnd1, cnd2) ->
      let* cnd1 = typed_cond sigs ctx cnd1 in
      let* cnd2 = typed_cond sigs ctx cnd2 in
      ok (Cond.disj cnd1 cnd2)


let rec pp_syntax_loc fmt (t : Syntax.Stmt.loc) =
  match t with
  | Syntax.Tree.Leaf v -> Format.pp_print_string fmt v
  | Syntax.Tree.Node l ->
      Format.fprintf fmt "@[<1>(%a)@]"
        (Format.pp_print_list ~pp_sep:pp_print_comma pp_syntax_loc)
        l


let rec typed_loc pos ctx (loc : Syntax.Stmt.loc) =
  match loc with
  | Syntax.Tree.Leaf string -> (
      match String.Map.find_opt string ctx with
      | None -> unknown_variable pos string
      | Some (v, ty) -> ok (Loc.var v ty, ty))
  | Syntax.Tree.Node l ->
      let* l = Result.List.map_collect (typed_loc pos ctx) l in
      let ll, lt = List.split l in
      ok (Loc.tuple ll, Type.tuple lt)


let rec typed_stmt sigs named rettyp ctx toplevel lst
    ({ value; startpos; _ } as syntax : Syntax.Stmt.t) =
  match value with
  | Syntax.Stmt.Decl (typ, loc, exp) -> (
      if not toplevel then error_pos startpos "non top-level declaration"
      else
        match Syntax.Tree.unify loc typ with
        | None ->
            error_pos startpos "cannot unify %a with type %a" pp_syntax_loc loc
              Type.pp typ
        | Some list -> (
            let* ctx =
              Result.List.fold_left_collect
                (fun ctx (string, typ) ->
                  if String.Map.mem string ctx then
                    error_pos startpos "variable %s is already defined" string
                  else ok (String.Map.add string (named string, typ) ctx))
                ctx list
            in
            match exp with
            | None -> ok (ctx, lst, false)
            | Some exp ->
                typed_stmt sigs named rettyp ctx false lst
                  Syntax.{ syntax with value = Stmt.Assign (loc, exp) }))
  | Syntax.Stmt.Assign (loc, exp) ->
      let* loc, tl = typed_loc startpos ctx loc in
      let* exp, te = typed_expr sigs ctx exp in
      if Syntax.Tree.similar tl te then
        ok (ctx, Stmt.(make startpos (Assign (loc, exp))) :: lst, false)
      else type_error startpos Expr.pp exp Type.pp te Type.pp tl
  | Syntax.Stmt.Do (string, exps) -> (
      let* either = typed_call sigs ctx startpos string exps in
      match either with
      | Either.Left (_, rettyp) ->
          type_error startpos Format.pp_print_string string Type.pp rettyp
            Type.pp_opt None
      | Either.Right stmt -> ok (ctx, Stmt.(make startpos stmt) :: lst, false))
  | Syntax.Stmt.Assert cnd ->
      let* cnd = typed_cond sigs ctx cnd in
      ok (ctx, Stmt.(make startpos (Assert cnd)) :: lst, false)
  | Syntax.Stmt.Return exp -> (
      let* exp, typ =
        match exp with
        | None -> ok (None, None)
        | Some exp ->
            let* exp, ty = typed_expr sigs ctx exp in
            ok (Some exp, Some ty)
      in
      match (exp, typ, rettyp) with
      | None, None, None ->
          ok (ctx, Stmt.(make startpos (Return None)) :: lst, true)
      | Some exp, Some ty, Some typ when Syntax.Tree.similar ty typ ->
          ok (ctx, Stmt.(make startpos (Return (Some exp))) :: lst, true)
      | _, _, _ ->
          type_error startpos Format.pp_print_string "return value" Type.pp_opt
            typ Type.pp_opt rettyp)
  | Syntax.Stmt.If (cnd, blk1, blk2) ->
      let* cnd = typed_cond sigs ctx cnd in
      let* ctx, blk1, ret1 = typed_block sigs named rettyp ctx false blk1 in
      let* ctx, blk2, ret2 = typed_block sigs named rettyp ctx false blk2 in
      ok (ctx, Stmt.(make startpos (If (cnd, blk1, blk2))) :: lst, ret1 && ret2)
  | Syntax.Stmt.While (cnd, blk) ->
      let* cnd = typed_cond sigs ctx cnd in
      let* ctx, blk, _ = typed_block sigs named rettyp ctx false blk in
      ok (ctx, Stmt.(make startpos (While (cnd, blk))) :: lst, false)


and typed_block sigs named rettyp ctx toplevel list =
  let* ctx, result, return =
    Result.List.fold_left_collect
      (fun (ctx, result, return) ({ startpos; _ } as stmt : Syntax.Stmt.t) ->
        if return then error_pos startpos "unreachable statement"
        else typed_stmt sigs named rettyp ctx toplevel result stmt)
      (ctx, [], false) list
  in
  ok (ctx, List.rev result, return)


let typed_func sigs ({ value; startpos; _ } : Syntax.Func.t) =
  let func_pos = startpos in
  let func_name = value.func_name in
  let func_rettyp = value.func_rettyp in
  let named = Var.named ~func:func_name in
  let ctx, func_params =
    List.fold_left_map
      (fun ctx (ty, s) ->
        let v = named s in
        (String.Map.add s (v, ty) ctx, (v, ty)))
      String.Map.empty value.func_params
  in
  let* ctx, func_body, return =
    typed_block sigs named value.func_rettyp ctx true value.func_body
  in
  let func_locals =
    List.fold_left
      (fun ctx (_, s) -> String.Map.remove s ctx)
      ctx value.func_params
    |> String.Map.bindings |> List.map snd
  in
  if func_rettyp <> None && not return then
    error_pos startpos "end of function %s reached without returning" func_name
  else
    ok
      Func.
        {
          func_pos;
          func_name;
          func_rettyp;
          func_params;
          func_locals;
          func_body;
        }


let typed_funcs list =
  let* _, list =
    Result.List.fold_left_collect
      (fun (sigs, funcs) func ->
        let* func = typed_func sigs func in
        ok
          ( String.Map.add func.func_name
              (func.func_rettyp, List.map snd func.func_params)
              sigs,
            func :: funcs ))
      (String.Map.empty, []) list
  in
  ok (List.rev list)


let typed_program file list =
  let* funcs = typed_funcs list in
  match
    List.find_opt (fun func -> String.equal func.Func.func_name "main") funcs
  with
  | None -> (
      match file with
      | "" -> error "No main function."
      | str -> error_format "File %s: no main function." str)
  | Some func -> (
      if func.Func.func_rettyp = None && List.length func.Func.func_params = 0
      then ok { environment = Env.make funcs; entrypoint = "main" }
      else
        match file with
        | "" -> error "Main function must have no parameters and return void."
        | str ->
            error_format
              "File %s: main function must have no parameters and return void."
              str)


let parse_program file =
  In_channel.with_open_text file (fun channel ->
      let lexbuf = Lexing.from_channel channel in
      Lexing.set_filename lexbuf file;
      try
        let syntax = Parser.main Lexer.token lexbuf in
        typed_program file syntax
      with
      | Lexer.Error (pos, msg) -> error_pos pos "%s" msg
      | Parser.Error -> error_pos (Lexing.lexeme_start_p lexbuf) "syntax error")


let parse_program file =
  match parse_program file with
  | Ok program -> program
  | Error error ->
      prerr_endline error;
      failwith file
