open Core

module Position = struct
  type t = Lexing.position = {
    pos_fname : string;
    pos_lnum : int;
    pos_bol : int;
    pos_cnum : int;
  }
  [@@deriving eq, ord, show { with_path = false }]
end

include Position
module Map = Map.Make (Position)
module Set = Set.Make (Position)

let debug fmt t = pp fmt t

let pp fmt { pos_fname; pos_lnum; _ } =
  match pos_fname with
  | "" -> Format.fprintf fmt "Line %d" pos_lnum
  | str -> Format.fprintf fmt "File %s at line %d" str pos_lnum


let pp_with_offset fmt { pos_fname; pos_lnum; pos_bol; pos_cnum } =
  match pos_fname with
  | "" -> Format.fprintf fmt "Line %d at offset %d" pos_lnum (pos_cnum - pos_bol)
  | str ->
      Format.fprintf fmt "File %s line %d at offset %d" str pos_lnum
        (pos_cnum - pos_bol)
