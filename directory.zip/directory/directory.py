from __future__ import annotations

# import stat

from enum import StrEnum
from datetime import datetime
from pathlib import PurePath
from typing import NamedTuple


class Color(StrEnum):
    DEFAULT = '\033[0m'
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'


class Stat(NamedTuple):
    st_path: PurePath
    st_sym: PurePath | None
    st_mode: int
    st_ino: int
    st_dev: int
    st_nlink: int
    st_uid: int
    st_gid: int
    st_size: int
    st_atime: float
    st_mtime: float
    st_ctime: float

    def print(self, color: bool = True):
        path = bytes(self.st_path).decode('ascii', 'backslashreplace')
        date = datetime.fromtimestamp(self.st_mtime).strftime('%y/%m/%d %H:%M:%S')

        mode = f'{self.st_mode:6o}'  # TODO
        size = f'{self.st_size:4}B'  # TODO
        colr = Color.DEFAULT         # TODO

        uid = f'{self.st_uid:5}'  # TODO https://docs.python.org/3/library/pwd.html
        gid = f'{self.st_uid:5}'  # TODO https://docs.python.org/3/library/grp.html

        print(f'{mode} {self.st_nlink:2} {uid} {gid} {size} {date} {colr if color else ""}{path}', end="")

        if self.st_sym:
            sym = bytes(self.st_sym).decode('ascii', 'backslashreplace')
            print(' ->', sym, end="")

        print(Color.DEFAULT if color else "")
