from __future__ import annotations

from enum import StrEnum
from typing import NamedTuple


# python 3.10 and below
#
# from enum import Enum
#
# class Color(str, Enum):
#     DEFAULT = '\033[0m'
#     BLACK = '\033[30m'
#     RED = '\033[31m'
#     GREEN = '\033[32m'
#     YELLOW = '\033[33m'
#     BLUE = '\033[34m'
#     MAGENTA = '\033[35m'
#     CYAN = '\033[36m'
#     WHITE = '\033[37m'

#     def __str__(self) -> str:
#         return self.value


class Color(StrEnum):
    RESET = '\033[0m'
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'


class Stat(NamedTuple):
    st_path: bytes
    st_sym: bytes | None
    st_mode: int
    st_ino: int
    st_dev: int
    st_nlink: int
    st_uid: int
    st_gid: int
    st_size: int
    st_atime: float
    st_mtime: float
    st_ctime: float
