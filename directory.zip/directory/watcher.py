from argparse import ArgumentParser


def main():
    parser = ArgumentParser()
    # Add options for the main parser here

    subparsers = parser.add_subparsers(dest='parser')
    
    parser_watch = subparsers.add_parser('watch', help='watch files and directories')
    parser_watch.add_argument('-r', '--recursive', action='store_true', help='watch subdirectories recursively')
    # Add options for the 'watch' subparser here

    args = parser.parse_args()
    match args.parser:
        case 'watch':
            ...
        case _:
            ...


if __name__ == '__main__':
    main()
