from argparse import ArgumentParser


def main():
    parser = ArgumentParser()
    # Add options for the main parser here

    subparsers = parser.add_subparsers(dest='parser')


    parser_watch = subparsers.add_parser('watch', help='watch files and directories')
    parser_watch.add_argument('-i', '--input', metavar='FILE', nargs='+', help='load watch(es) from input file(s)')
    parser_watch.add_argument('-o', '--output', metavar='FILE', help='save watch to output file')
    parser_watch.add_argument('-r', '--recursive', action='store_true', help='watch subdirectories recursively')
    parser_watch.add_argument('paths', metavar='PATHS', nargs='*', help='select files and directories to watch')

    args = parser.parse_args()
    print(args)

    match args.parser:
        case 'watch':
            ...
        case _:
            ...


if __name__ == '__main__':
    main()
